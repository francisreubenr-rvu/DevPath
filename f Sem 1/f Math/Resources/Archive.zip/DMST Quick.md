# DISCRETE MATHEMATICS: QUICK REVISION CHEAT SHEET
## One-Page Summary for Last-Minute Prep

---

## SET THEORY AT A GLANCE

### Definitions
- **Set:** Well-defined collection of distinct objects
- **Subset:** \(A \subseteq B\) iff every element of A is in B
- **Power Set:** \(\mathcal{P}(A)\) = all subsets of A; \(|\mathcal{P}(A)| = 2^{|A|}\)
- **Cartesian Product:** \(A \times B = \{(a,b) | a \in A, b \in B\}\); \(|A \times B| = |A| \cdot |B|\)

### Operations
| Operation | Symbol | Definition |
|-----------|--------|-----------|
| Union | \(A \cup B\) | Elements in A or B (or both) |
| Intersection | \(A \cap B\) | Elements in both A and B |
| Complement | \(A^c\) | Elements in U but not in A |
| Difference | \(A \setminus B\) | Elements in A but not in B |
| Symmetric Diff | \(A \oplus B\) | Elements in exactly one of A or B |

### Key Formulas
- **Inclusion-Exclusion (2 sets):** \(|A \cup B| = |A| + |B| - |A \cap B|\)
- **Inclusion-Exclusion (3 sets):** \(|A \cup B \cup C| = |A| + |B| + |C| - |A \cap B| - |A \cap C| - |B \cap C| + |A \cap B \cap C|\)
- **De Morgan's Laws:** \((A \cup B)^c = A^c \cap B^c\); \((A \cap B)^c = A^c \cup B^c\)

---

## RELATIONS & FUNCTIONS

### Relation Properties (on set A)

| Property | Condition | Example |
|----------|-----------|---------|
| **Reflexive** | \((a,a) \in R \, \forall a \in A\) | \(\leq\) on \(\mathbb{R}\) |
| **Symmetric** | \((a,b) \in R \Rightarrow (b,a) \in R\) | "is sibling of" |
| **Transitive** | \((a,b), (b,c) \in R \Rightarrow (a,c) \in R\) | "ancestor of" |
| **Antisymmetric** | \((a,b), (b,a) \in R \Rightarrow a = b\) | \(\leq\) on \(\mathbb{R}\) |
| **Equivalence** | Reflexive + Symmetric + Transitive | Modular congruence |

### Functions: Key Properties

- **Injective (1-1):** \(f(x_1) = f(x_2) \Rightarrow x_1 = x_2\)
- **Surjective (onto):** For all \(y \in B, \exists x \in A: f(x) = y\)
- **Bijective:** Both injective and surjective; inverse \(f^{-1}\) exists
- **Composition:** \((g \circ f)(x) = g(f(x))\); NOT commutative

---

## PROPOSITIONAL LOGIC

### Truth Tables (One Row Each Showing FALSE Cases)

| Operation | Symbol | False When |
|-----------|--------|-----------|
| Negation | \(\neg p\) | p is T |
| Conjunction | \(p \land q\) | Either p or q is F |
| Disjunction | \(p \lor q\) | Both p and q are F |
| Conditional | \(p \rightarrow q\) | p is T and q is F |
| Biconditional | \(p \leftrightarrow q\) | p and q have different truth values |

### Key Equivalences
- \(\neg(\neg p) \equiv p\) (Double negation)
- \(\neg(p \land q) \equiv \neg p \lor \neg q\) (De Morgan's 1)
- \(\neg(p \lor q) \equiv \neg p \land \neg q\) (De Morgan's 2)
- \(p \rightarrow q \equiv \neg p \lor q\) (Conditional equivalence)
- \(p \rightarrow q \equiv \neg q \rightarrow \neg p\) (Contrapositive - EQUIVALENT)
- \(\neg(p \rightarrow q) \equiv p \land \neg q\)

### Quantifiers
- \(\forall x, P(x)\): "For all x, P(x)" — FALSE iff \(\exists x\) where P(x) is false
- \(\exists x, P(x)\): "There exists x, P(x)" — TRUE iff at least one x makes P(x) true
- **Negation:** \(\neg(\forall x, P(x)) \equiv \exists x, \neg P(x)\)
- **Negation:** \(\neg(\exists x, P(x)) \equiv \forall x, \neg P(x)\)

---

## COUNTING PRINCIPLES

### Fundamental Rules
- **Multiplication:** If E has m ways and F has n ways, total = \(m \times n\)
- **Addition:** If E has m ways and F has n ways (mutually exclusive), total = \(m + n\)

### Permutations & Combinations

| Type | Formula | When to Use |
|------|---------|-----------|
| **P(n,n)** | \(n!\) | Arrange all n distinct objects |
| **P(n,r)** | \(\frac{n!}{(n-r)!}\) | Arrange r from n; ORDER MATTERS |
| **C(n,r)** | \(\frac{n!}{r!(n-r)!}\) | Choose r from n; order doesn't matter |
| **Repetition allowed** | \(n^r\) | Permutations with replacement |
| **With repetitions** | \(\frac{n!}{n_1! \cdot n_2! \cdots n_k!}\) | Arrange n objects with identical groups |

### Quick Permutation/Combination Relationship
\[P(n,r) = r! \times C(n,r)\]

### Catalan Numbers
\[C_n = \frac{1}{n+1}\binom{2n}{n}\]
**Sequence:** 1, 1, 2, 5, 14, 42, 132, ...

### Pigeonhole Principle
- If n objects in k containers and \(n > k\), then some container has \(\geq 2\) objects
- **General:** At least one container has \(\geq \lceil \frac{n}{k} \rceil\) objects

---

## MATHEMATICAL INDUCTION TEMPLATE

**To Prove:** P(n) true for all \(n \geq 1\)

1. **Base Case:** Show P(1) is TRUE
2. **Inductive Hypothesis:** Assume P(k) is TRUE for some \(k \geq 1\)
3. **Inductive Step:** Using P(k), prove P(k+1) is TRUE
4. **Conclusion:** By MI, P(n) is TRUE for all \(n \geq 1\)

**Common Formula:** \(\sum_{i=1}^{n} i = \frac{n(n+1)}{2}\)

---

## BINOMIAL THEOREM

### Expansion
\[(x + y)^n = \sum_{r=0}^{n} \binom{n}{r} x^{n-r} y^r\]

### Useful Corollaries
- Setting \(x = y = 1\): \(\sum_{r=0}^{n} \binom{n}{r} = 2^n\)
- Setting \(x = 1, y = -1\): \(\sum_{r=0}^{n} (-1)^r \binom{n}{r} = 0\)

### Binomial Coefficient Identities
- \(\binom{n}{r} = \binom{n}{n-r}\) (Symmetry)
- \(\binom{n}{r} = \binom{n-1}{r-1} + \binom{n-1}{r}\) (Pascal's Identity)

---

## COMMONLY CONFUSED CONCEPTS

| Concept | Definition | Example |
|---------|-----------|---------|
| **Permutation** | ORDER MATTERS | ABC vs BAC are different |
| **Combination** | ORDER DOESN'T MATTER | {A,B,C} is one selection |
| **Relation** | Any subset of A×B | Can have multiple outputs per input |
| **Function** | Special relation, one output per input | f(x) = 2x + 1 |
| **Injective** | No two inputs map to same output | Each y has at most one preimage |
| **Surjective** | Every output has at least one input | Every y has at least one preimage |

---

## PROOF STRATEGIES

| Strategy | When to Use | Approach |
|----------|-----------|----------|
| **Direct** | Always try first | Assume hypothesis, deduce conclusion |
| **Contrapositive** | Negations easier | To prove \(p \rightarrow q\), prove \(\neg q \rightarrow \neg p\) |
| **Contradiction** | Unnatural forms | Assume negation, derive contradiction |
| **Induction** | Sequences/sums | Base case + inductive step |

---

## QUICK PROBLEM-SOLVING CHECKLIST

✓ **Set Problems:** Draw Venn diagrams; use inclusion-exclusion
✓ **Counting Problems:** Ask "does order matter?" → Permutation (YES) or Combination (NO)
✓ **Logic Problems:** Construct truth tables; identify tautologies/contradictions
✓ **Relation Problems:** Check all five properties (reflexive, symmetric, transitive, antisymmetric)
✓ **Function Problems:** Verify domain/range; test injectivity and surjectivity
✓ **Proof Problems:** State what to prove; choose strategy; write clearly

---

## TOP 10 MUST-KNOW FORMULAS

1. \(n! = n \times (n-1) \times \cdots \times 1\)
2. \(P(n,r) = \frac{n!}{(n-r)!}\)
3. \(C(n,r) = \frac{n!}{r!(n-r)!}\)
4. \(|A \cup B| = |A| + |B| - |A \cap B|\)
5. \((x+y)^n = \sum_{r=0}^{n} \binom{n}{r} x^{n-r} y^r\)
6. \(C_n = \frac{1}{n+1}\binom{2n}{n}\) (Catalan)
7. \(\sum_{i=1}^{n} i = \frac{n(n+1)}{2}\)
8. \(p \rightarrow q \equiv \neg p \lor q\)
9. \((A \cup B)^c = A^c \cap B^c\)
10. \(\neg(\forall x, P(x)) \equiv \exists x, \neg P(x)\)

---

## FINAL EXAM TIPS

⏱️ **Time Management:** Spend 1-2 min on MCQs, 5-10 min on problems, 10-15 min on proofs

📝 **Strategy:**
1. Read all questions first
2. Solve easy questions first (build confidence)
3. Show all work (partial credit)
4. Use diagrams liberally (Venn, truth tables, etc.)
5. Double-check arithmetic in final answers

🎯 **Common Mistakes to Avoid:**
- Confusing permutations with combinations
- Forgetting to subtract overlaps in inclusion-exclusion
- Assuming converse ≡ original statement in logic
- Not checking all properties for relations
- Incomplete proofs (stating without justification)

---

**Good Luck! You've got this! 💪**
