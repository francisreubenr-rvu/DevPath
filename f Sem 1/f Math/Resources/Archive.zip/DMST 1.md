<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Master Prompt — “Create the Ultimate Notes”

I am a first-year Computer Science student at RV University. I need you to create the ultimate, hyper-detailed, and comprehensive set of study notes based on the materials I provide (such as PDFs, slides, or topic names).
These notes must serve as the only resource I’ll need to completely master the subject and perform excellently in exams or competitions.
You may use the attached PDFs as the primary source and scour the internet to gather, cross-verify, and expand upon the information where necessary.
Follow the detailed instructions below with precision and consistency.

1. Purpose and Context
The notes are intended for exam or competition preparation.
Treat the material as confidential and approach the task with academic rigor and attention to detail.
The notes should be accurate, reliable, and easy to revise.
When a test time or subject is mentioned, tailor your output to optimize for the remaining time and expected question style (MCQs, descriptive, coding, etc.).
2. Source Hierarchy
Primary Source: The attached PDFs, slides, or documents.
Secondary Source: Verified web references, textbooks, or research articles.
Tertiary Sources (if needed): Expert explanations, tutorials, or standard university materials for clarification only.
If a conflict arises between sources:
Prefer the attached PDFs.
If a web source provides deeper or newer insight, note the addition separately and justify briefly.
3. Structure and Formatting Requirements
Your output must be organized, readable, and revision-friendly. Follow this hierarchy strictly:
A. Overall Layout
Begin with a Title and short summary paragraph (3–5 sentences) describing the overall theme and learning objectives.
Divide content into Modules → Units → Topics → Subtopics as needed.
B. For Each Topic
Include the following sections wherever relevant:
Definition / Concept Introduction
Detailed Explanation with clear indentation and sub-points
Diagrams, flowcharts, or labeled illustrations (include alt text and captions)
Tables comparing key features, pros/cons, parameters, or differences
Examples and Applications — real-world or code-based
Advantages / Merits / Demerits / Limitations (preferably in a concise table)
Common Mistakes or Misconceptions
Key Formulas, Units, and Constants (if applicable)
Practice Questions (both MCQs and descriptive) with answers and brief explanations
Summary or Quick Review (2–3 sentences per topic)
C. End-of-Module Additions
Module Summary: 3–5 key insights or takeaways
Top 10 Most Testable Facts
Common Question Patterns with short answers
Mini Quiz: 5–10 mixed-type questions (MCQ, short answer, code snippet interpretation, etc.)
“Cheat Sheet” or One-Page Review Table highlighting the most crucial data, formulas, and definitions
4. Formatting Standards
Use Markdown or APA format, depending on the topic and context.
Use clear headings (H1–H4) and consistent indentation for hierarchy.
Bold key terms, italicize secondary emphasis, and use tables and lists generously.
Keep each major topic self-contained and easy to study independently.
Where helpful, include visual separators like lines or spacing for readability.
Add APA-style citations for all external references at the end.
5. Depth and Completeness
Cover every subtopic thoroughly — definitions, theory, practical examples, and exceptions.
For programming topics: include code samples, annotations, edge cases, and common errors.
For theoretical topics: include diagrams, derivations, and comparative tables.
For applied topics: include real-world use cases and recent developments (if relevant).
6. Quality Assurance
Before presenting the final notes, ensure:
All information is accurate, verified, and clearly explained.
The notes can stand alone as a complete study guide.
The writing style is concise, formal, and academic, avoiding filler text.
The final output reads like a professionally edited set of university notes.
7. Deliverables
Main Document:
Fully formatted notes (Markdown, APA, or DOCX style).
Includes summaries, tables, examples, and diagrams.
Quick Review Version:
A condensed 1–2 page summary or cheat sheet for last-minute revision.
References Section:
APA citations for any web or external sources used.
8. Optional Enhancements (if time permits)
Include a study plan or preparation strategy for the given test.
Add mnemonics or memory aids for formula-heavy topics.
Provide color-coded table suggestions (e.g., red = limitations, green = advantages, blue = examples).
Create a “Common Questions vs Concepts” mapping table for quick cross-referencing.

I'll create comprehensive, exam-ready notes for your Discrete Mathematics course based on all the materials provided. This will be structured according to your detailed requirements.

# **DISCRETE MATHEMATICS - ULTIMATE STUDY NOTES**

## RV University | Computer Science - First Year


***

## **📋 MODULE OVERVIEW AND LEARNING OBJECTIVES**

This comprehensive guide covers the foundational concepts of Discrete Mathematics, focusing on four core modules essential for Computer Science students. These notes are designed to be your **complete and only resource** for mastering the subject.

**Learning Objectives:**

- Master set theory operations and properties for problem-solving
- Apply propositional logic to construct and analyze logical arguments
- Understand and work with relations and functions in mathematical contexts
- Solve complex counting problems using permutations, combinations, and advanced principles

***

# **MODULE 1: SET THEORY**

## **1.1 Introduction to Sets**

### **Definition**

A **set** is a well-defined collection of distinct objects. Each object in the set is called an **element** or **member** of the set.[^1]

### **Key Concepts**

**Notation:**

- Sets are denoted by capital letters: A, B, C, etc.
- Elements are denoted by lowercase letters: a, b, c, etc.
- Membership: `x ∈ A` means "x belongs to A"
- Non-membership: `x ∉ A` means "x does not belong to A"

**Example:**

```
A = {2, 4, 6, 8}
Here: 4 ∈ A but 5 ∉ A
```


### **Standard Sets**[^1]

| Symbol | Set | Description |
| :-- | :-- | :-- |
| **N** | Natural Numbers | {1, 2, 3, 4, ...} |
| **Z** or **I** | Integers | {..., -3, -2, -1, 0, 1, 2, 3, ...} |
| **Q** | Rational Numbers | {p/q where p, q ∈ Z and q ≠ 0} |
| **Q'** | Irrational Numbers | Numbers that cannot be expressed as p/q |
| **R** | Real Numbers | Q ∪ Q' |
| **C** | Complex Numbers | {a + ib where a, b ∈ R and i = √-1} |


***

## **1.2 Representation of Sets**

### **Method 1: Roster Form (Tabular Form)**[^1]

List all elements separated by commas within braces.

**Examples:**

- A = {2, 4, 8, 16, ...} → set of positive powers of 2
- B = {a, e, i, o, u} → set of vowels


### **Method 2: Set-Builder Form (Rule Method)**[^1]

Describe elements using a property or rule.

**Format:** `X = {x | condition on x}`

**Examples:**

- A = {x | x is a prime number between 2 and 10}
- B = {x | x² = 9, x ∈ Z}


### **Interval Notation**[^1]

| Notation | Description | Inequality |
| :-- | :-- | :-- |
| **[a, b]** | Closed interval | a ≤ x ≤ b |
| **(a, b)** | Open interval | a < x < b |
| **[a, b)** | Semi-closed | a ≤ x < b |
| **(a, b]** | Semi-open | a < x ≤ b |


***

## **1.3 Cardinality of Sets**

### **Definition**[^1]

The **cardinality** (or **order**) of a set A, denoted by **n(A)** or **|A|**, is the number of elements in the set.

**Examples:**

- A = {5, 7, 9, 11, 13} → n(A) = 5
- B = ∅ (empty set) → n(B) = 0

**Important Note:** The cardinality of the empty set is zero.

***

## **1.4 Types of Sets**

### **1.4.1 Empty Set (Null Set)**[^1]

**Definition:** A set with no elements.
**Notation:** ∅ or { }

**Example:** Set of natural numbers less than 1 = ∅

***

### **1.4.2 Singleton Set (Unit Set)**[^1]

**Definition:** A set with exactly one element.

**Example:** B = {0}, C = {set of even prime numbers} = {2}

***

### **1.4.3 Finite vs. Infinite Sets**[^1]

**Finite Set:** Contains a countable number of elements.

- Example: A = {10, 20, 30}

**Infinite Set:** Contains uncountably many elements.

- Example: B = {set of all integers divisible by 3}

***

### **1.4.4 Equal Sets**[^1]

**Definition:** Two sets are equal if they contain exactly the same elements.

**Example:**

- A = {1, 2, 3}
- B = {3, 1, 2}
- Here, A = B (order doesn't matter)

***

### **1.4.5 Equivalent Sets**[^1]

**Definition:** Sets with the same number of elements (same cardinality) but not necessarily the same elements.

**Notation:** A ~ B

**Example:**

- A = {1, 2, 3}, B = {a, b, c}
- n(A) = n(B) = 3, so A ~ B

***

### **1.4.6 Subset and Superset**[^1]

**Subset:** Set A is a subset of B (A ⊆ B) if every element of A is also in B.

**Proper Subset:** A ⊂ B if A ⊆ B and A ≠ B (B contains at least one element not in A).

**Superset:** If A ⊆ B, then B ⊇ A (B is a superset of A).

**Example:**

- A = {5, 7}, B = {5, 7, 8, 9}
- A ⊂ B (A is a proper subset of B)

***

### **1.4.7 Universal Set**[^1]

**Definition:** A set containing all elements under consideration in a particular context.
**Notation:** U

**Example:** If discussing vowels and consonants, U = {all letters in English alphabet}

***

### **1.4.8 Power Set**[^1]

**Definition:** The power set of A, denoted P(A), is the set of all possible subsets of A, including ∅ and A itself.

**Formula:** If n(A) = n, then n(P(A)) = 2ⁿ

**Example:**

```
A = {2, 4, 6}
P(A) = {∅, {2}, {4}, {6}, {2,4}, {2,6}, {4,6}, {2,4,6}}
n(A) = 3, n(P(A)) = 2³ = 8
```


***

## **1.5 Venn Diagrams**[^2]

### **Definition**

A **Venn diagram** is a visual representation showing relationships between sets using circles within a rectangle (representing the universal set U).

### **Common Venn Diagram Representations**[^2]

| Relationship | Diagram Description |
| :-- | :-- |
| **A ∩ B** | Overlapping region of circles A and B |
| **A ∪ B** | Combined area of both circles |
| **A - B** | Area in A but not in B |
| **A'** | Area outside circle A but inside U |
| **A ⊂ B** | Circle A entirely inside circle B |
| **Disjoint Sets** | Circles A and B don't touch |


***

## **1.6 Set Operations**

### **1.6.1 Union (∪)**[^2]

**Definition:** The union of sets A and B contains all elements in A or B or both.

**Notation:** A ∪ B = {x | x ∈ A or x ∈ B}

**Example:**

```
A = {2, 4, 6}, B = {4, 5, 6, 7}
A ∪ B = {2, 4, 5, 6, 7}
```


***

### **1.6.2 Intersection (∩)**[^2]

**Definition:** The intersection of A and B contains only elements common to both sets.

**Notation:** A ∩ B = {x | x ∈ A and x ∈ B}

**Example:**

```
A = {2, 4, 6}, B = {4, 5, 6, 7}
A ∩ B = {4, 6}
```


***

### **1.6.3 Complement (')**[^2]

**Definition:** The complement of set A contains all elements in the universal set U that are NOT in A.

**Notation:** A' or Aᶜ = U - A = {x | x ∈ U and x ∉ A}

**Example:**

```
U = {1, 2, 3, 4, 5, 6}, A = {2, 4}
A' = {1, 3, 5, 6}
```


***

### **1.6.4 Difference (-)**[^2]

**Definition:** The difference A - B contains elements in A but not in B.

**Notation:** A - B = {x | x ∈ A and x ∉ B}

**Example:**

```
A = {2, 4, 6}, B = {4, 5, 6, 7}
A - B = {2}
B - A = {5, 7}
```


***

### **1.6.5 Symmetric Difference (Δ)**[^2]

**Definition:** Contains elements in either A or B, but NOT in both.

**Notation:** A Δ B = (A - B) ∪ (B - A)

**Example:**

```
A = {1, 2, 3, 4, 5, 6}, B = {2, 4, 6, 8, 10}
A Δ B = {1, 3, 5, 8, 10}
```


***

## **1.7 Laws and Properties of Sets**[^2]

### **1.7.1 Basic Laws**

| Law | Formula |
| :-- | :-- |
| **Identity Laws** | A ∪ ∅ = A; A ∩ U = A |
| **Domination Laws** | A ∪ U = U; A ∩ ∅ = ∅ |
| **Idempotent Laws** | A ∪ A = A; A ∩ A = A |
| **Complementation Law** | (A')' = A |

### **1.7.2 Commutative Laws**[^2]

- A ∪ B = B ∪ A
- A ∩ B = B ∩ A


### **1.7.3 Associative Laws**[^2]

- A ∪ (B ∪ C) = (A ∪ B) ∪ C
- A ∩ (B ∩ C) = (A ∩ B) ∩ C


### **1.7.4 Distributive Laws**[^2]

- A ∪ (B ∩ C) = (A ∪ B) ∩ (A ∪ C)
- A ∩ (B ∪ C) = (A ∩ B) ∪ (A ∩ C)


### **1.7.5 De Morgan's Laws**[^2]

- **(A ∪ B)' = A' ∩ B'**
- **(A ∩ B)' = A' ∪ B'**


### **1.7.6 Absorption Laws**[^2]

- A ∪ (A ∩ B) = A
- A ∩ (A ∪ B) = A


### **1.7.7 Complement Laws**[^2]

- A ∪ A' = U
- A ∩ A' = ∅
- U' = ∅
- ∅' = U


### **1.7.8 Set Difference Law**[^2]

- **A - B = A ∩ B'**
- **A - B ≠ B - A** (not commutative)

***

## **1.8 Solved Examples - Sets**

### **Example 1:** Find A ∪ B, A ∩ B, A', and A - B

```
U = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
A = {2, 4, 6, 8}, B = {1, 3, 5, 7, 9}

Solution:
A ∪ B = {1, 2, 3, 4, 5, 6, 7, 8, 9}
A ∩ B = ∅ (disjoint sets)
A' = {1, 3, 5, 7, 9, 10}
A - B = {2, 4, 6, 8}
```


### **Example 2:** Verify De Morgan's Law (A ∪ B)' = A' ∩ B'

```
U = {1, 2, 3, 4, 5, 6}
A = {1, 2, 3}, B = {3, 4, 5}

Solution:
LHS: A ∪ B = {1, 2, 3, 4, 5}
     (A ∪ B)' = {6}

RHS: A' = {4, 5, 6}, B' = {1, 2, 6}
     A' ∩ B' = {6}

LHS = RHS ✓ Verified
```


***

## **1.9 Common Mistakes and Misconceptions**

❌ **Mistake 1:** Confusing ∅ with {∅}

- ∅ has no elements (n(∅) = 0)
- {∅} has one element, the empty set itself (n({∅}) = 1)

❌ **Mistake 2:** Thinking A - B = B - A

- Set difference is NOT commutative

❌ **Mistake 3:** Forgetting the universal set when finding complement

- Always specify U before finding A'

***

## **1.10 Quick Review - Module 1**

**Key Formulas:**

1. n(P(A)) = 2ⁿ where n = n(A)
2. A - B = A ∩ B'
3. (A')' = A
4. A ∪ A' = U; A ∩ A' = ∅

**Top 10 Testable Facts:**

1. Empty set is a subset of every set
2. Every set is a subset of itself
3. De Morgan's Laws for complements
4. Distributive laws work both ways
5. Union and intersection are commutative
6. Set difference is NOT commutative
7. Power set always has 2ⁿ elements
8. Complement laws with universal set
9. Idempotent property of union/intersection
10. Absorption laws simplify expressions

***

# **MODULE 2: PROPOSITIONAL LOGIC**

## **2.1 Introduction to Propositional Logic**[^3]

### **Definition**

**Propositional Logic** is the branch of logic that studies relationships between propositions using logical connectives to form complex statements.

### **Proposition**[^3]

A **proposition** is a declarative statement that is either **true** (T or 1) or **false** (F or 0), but not both.

**Examples of Propositions:**
✅ "2 + 2 = 4" (True)
✅ "Bangalore is the capital of Kerala" (False)
✅ "√2 is irrational" (True)

**Examples of Non-Propositions:**
❌ "How are you?" (Question)
❌ "Do your homework!" (Command)
❌ "x + 5 = 10" (Open sentence - truth depends on x)

### **Truth Value**[^3]

The **truth value** of a proposition is its truth or falsity:

- **True** → denoted as **T** or **1**
- **False** → denoted as **F** or **0**

**Notation:** Propositions are denoted by lowercase letters: p, q, r, s, etc.

***

## **2.2 Logical Connectives**[^3]

Logical connectives are words/phrases used to combine propositions into compound propositions.

### **2.2.1 Negation (¬ or ~)**[^3]

**Symbol:** ¬p or ~p (read as "NOT p")

**Definition:** The negation of p has the opposite truth value of p.

**Truth Table:**


| p | ¬p |
| :-- | :-- |
| T | F |
| F | T |

**Example:**

- p: "It is raining"
- ¬p: "It is NOT raining"

***

### **2.2.2 Conjunction (∧)**[^3]

**Symbol:** p ∧ q (read as "p AND q")

**Definition:** True only when BOTH p and q are true.

**Truth Table:**


| p | q | p ∧ q |
| :-- | :-- | :-- |
| T | T | **T** |
| T | F | F |
| F | T | F |
| F | F | F |

**Example:**

- p: "5 is odd"
- q: "6 is even"
- p ∧ q: "5 is odd AND 6 is even" (True)

***

### **2.2.3 Disjunction (∨)**[^3]

**Symbol:** p ∨ q (read as "p OR q")

**Definition:** False only when BOTH p and q are false.

**Truth Table:**


| p | q | p ∨ q |
| :-- | :-- | :-- |
| T | T | T |
| T | F | T |
| F | T | T |
| F | F | **F** |

**Example:**

- p: "I play cricket"
- q: "I go to a movie"
- p ∨ q: "I play cricket OR I go to a movie"

***

### **2.2.4 Conditional/Implication (→)**[^3]

**Symbol:** p → q (read as "if p then q" or "p implies q")

**Definition:** False only when p is true and q is false.

- p is called the **hypothesis/antecedent**
- q is called the **conclusion/consequent**

**Truth Table:**


| p | q | p → q |
| :-- | :-- | :-- |
| T | T | T |
| T | F | **F** |
| F | T | T |
| F | F | T |

**Key Insight:** A conditional is false ONLY when a true hypothesis leads to a false conclusion.

**Example:**

- p: "It rains"
- q: "The ground is wet"
- p → q: "If it rains, then the ground is wet"

***

### **2.2.5 Biconditional (↔)**[^3]

**Symbol:** p ↔ q (read as "p if and only if q" or "p iff q")

**Definition:** True when p and q have the SAME truth value.

**Truth Table:**


| p | q | p ↔ q |
| :-- | :-- | :-- |
| T | T | **T** |
| T | F | F |
| F | T | F |
| F | F | **T** |

**Note:** p ↔ q is equivalent to (p → q) ∧ (q → p)

**Example:**

- p: "A quadrilateral is a parallelogram"
- q: "Opposite sides are parallel"
- p ↔ q: "A quadrilateral is a parallelogram iff opposite sides are parallel"

***

## **2.3 Compound Propositions**[^3]

A **compound proposition** is formed by combining two or more propositions using logical connectives.

### **Constructing Truth Tables**

**Steps:**

1. Identify all atomic propositions (p, q, r, ...)
2. Determine number of rows: **2ⁿ** where n = number of atomic propositions
3. List all possible combinations of truth values
4. Evaluate the compound proposition step by step

**Example:** Construct truth table for (p ∧ q) → r


| p | q | r | p ∧ q | (p ∧ q) → r |
| :-- | :-- | :-- | :-- | :-- |
| T | T | T | T | T |
| T | T | F | T | F |
| T | F | T | F | T |
| T | F | F | F | T |
| F | T | T | F | T |
| F | T | F | F | T |
| F | F | T | F | T |
| F | F | F | F | T |


***

## **2.4 Types of Compound Propositions**

### **2.4.1 Tautology**[^3]

**Definition:** A compound proposition that is ALWAYS TRUE regardless of truth values of its components.

**Example:** p ∨ ¬p (Law of Excluded Middle)


| p | ¬p | p ∨ ¬p |
| :-- | :-- | :-- |
| T | F | **T** |
| F | T | **T** |

All entries in final column are T → **Tautology**

***

### **2.4.2 Contradiction**[^3]

**Definition:** A compound proposition that is ALWAYS FALSE.

**Example:** p ∧ ¬p


| p | ¬p | p ∧ ¬p |
| :-- | :-- | :-- |
| T | F | **F** |
| F | T | **F** |

All entries in final column are F → **Contradiction**

***

### **2.4.3 Contingency**

**Definition:** A compound proposition that is neither a tautology nor a contradiction (has both T and F values).

**Example:** p → q

***

## **2.5 Logical Equivalences**[^4]

### **Definition**

Two compound propositions are **logically equivalent** if they have identical truth values in all possible cases.

**Notation:** p ≡ q or p ⟺ q

### **Important Logical Equivalences**

| Law | Equivalence |
| :-- | :-- |
| **Double Negation** | ¬(¬p) ≡ p |
| **De Morgan's Laws** | ¬(p ∧ q) ≡ ¬p ∨ ¬q |
|  | ¬(p ∨ q) ≡ ¬p ∧ ¬q |
| **Conditional** | p → q ≡ ¬p ∨ q |
|  | p → q ≡ ¬q → ¬p (contrapositive) |
| **Biconditional** | p ↔ q ≡ (p → q) ∧ (q → p) |
| **Commutative** | p ∧ q ≡ q ∧ p |
|  | p ∨ q ≡ q ∨ p |
| **Associative** | (p ∧ q) ∧ r ≡ p ∧ (q ∧ r) |
|  | (p ∨ q) ∨ r ≡ p ∨ (q ∨ r) |
| **Distributive** | p ∧ (q ∨ r) ≡ (p ∧ q) ∨ (p ∧ r) |
|  | p ∨ (q ∧ r) ≡ (p ∨ q) ∧ (p ∨ r) |


***

## **2.6 Conditional Statements - Variations**[^5]

For a conditional p → q:


| Name | Form | Relationship |
| :-- | :-- | :-- |
| **Original** | p → q | Given |
| **Converse** | q → p | NOT equivalent to original |
| **Inverse** | ¬p → ¬q | NOT equivalent to original |
| **Contrapositive** | ¬q → ¬p | **Equivalent to original** |

**Key Result:**

- **p → q ≡ ¬q → ¬p** (Contrapositive equivalence)
- Converse ≡ Inverse (but NOT equivalent to original)

***

## **2.7 Solved Examples - Logic**

### **Example 1:** Prove (p → q) ∧ (p → r) ≡ p → (q ∧ r)

**Solution Using Truth Table:**


| p | q | r | p → q | p → r | (p → q) ∧ (p → r) | q ∧ r | p → (q ∧ r) |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| T | T | T | T | T | T | T | T |
| T | T | F | T | F | F | F | F |
| T | F | T | F | T | F | F | F |
| T | F | F | F | F | F | F | F |
| F | T | T | T | T | T | T | T |
| F | T | F | T | T | T | F | T |
| F | F | T | T | T | T | F | T |
| F | F | F | T | T | T | F | T |

Columns 6 and 8 are identical → **Logically Equivalent** ✓

***

### **Example 2:** Given p has truth value 0 (F), q has truth value 0 (F), r has truth value 1 (T). Find truth value of (p ∧ q) ∨ r.

**Solution:**

```
p = F, q = F, r = T

(p ∧ q) ∨ r
= (F ∧ F) ∨ T
= F ∨ T
= T

Answer: Truth value is T (1)
```


***

## **2.8 Common Mistakes**

❌ **Mistake 1:** Confusing p → q with q → p (converse)

- Original and converse are NOT equivalent

❌ **Mistake 2:** Thinking ¬(p ∧ q) = ¬p ∧ ¬q

- Correct: ¬(p ∧ q) = ¬p ∨ ¬q (De Morgan's Law)

❌ **Mistake 3:** Assuming p → q is false when p is false

- When hypothesis is false, implication is always true

***

## **2.9 Quick Review - Module 2**

**Priority of Operations (Highest to Lowest):**

1. Negation (¬)
2. Conjunction (∧)
3. Disjunction (∨)
4. Conditional (→)
5. Biconditional (↔)

**Top 10 Testable Facts:**

1. De Morgan's Laws for negation
2. Conditional equivalence: p → q ≡ ¬p ∨ q
3. Contrapositive equivalence
4. Tautology: p ∨ ¬p
5. Contradiction: p ∧ ¬p
6. Implication is false only when T → F
7. Biconditional true when both have same truth value
8. Double negation law
9. Distributive laws for ∧ and ∨
10. Number of rows in truth table = 2ⁿ

***

# **MODULE 3: RELATIONS AND FUNCTIONS**

## **3.1 Cartesian Product**[^6]

### **Definition**

The **Cartesian product** of two sets A and B, denoted A × B, is the set of all ordered pairs (a, b) where a ∈ A and b ∈ B.

**Notation:** A × B = {(a, b) | a ∈ A, b ∈ B}

**Example:**

```
A = {1, 2}, B = {5, 6}
A × B = {(1,5), (1,6), (2,5), (2,6)}
B × A = {(5,1), (6,1), (5,2), (6,2)}
```


### **Properties of Cartesian Product**[^6]

1. **Not Commutative:** A × B ≠ B × A (unless A = B or one is empty)
2. **Cardinality:** n(A × B) = n(A) × n(B)
3. **Order Matters:** (a, b) ≠ (b, a) unless a = b
4. **Empty Set:** If A = ∅ or B = ∅, then A × B = ∅
5. **Cartesian Product of Multiple Sets:** A × B × C = {(a, b, c) | a ∈ A, b ∈ B, c ∈ C}

***

## **3.2 Relations**[^6]

### **Definition**

A **relation** R from set A to set B is a subset of A × B.

**Notation:** R ⊆ A × B

### **Representation**

**1. Ordered Pairs:** R = {(1, 2), (3, 4), (5, 6)}

**2. Arrow Diagram:** Visual representation with arrows from elements of A to elements of B

**3. Matrix Representation:**

- Rows labeled by elements of A
- Columns labeled by elements of B
- Entry is 1 if (a, b) ∈ R, otherwise 0

**Example:**

```
A = {1, 2, 3}, B = {a, b}
R = {(1, a), (2, b), (3, a)}

Matrix MR:
      a  b
  1 [ 1  0 ]
  2 [ 0  1 ]
  3 [ 1  0 ]
```


### **Domain, Range, and Codomain**[^6]

- **Domain:** Set of all first elements in ordered pairs of R
- **Range:** Set of all second elements in ordered pairs of R
- **Codomain:** The set B (may include elements not in range)

**Example:**

```
R = {(1, 3), (2, 4), (3, 5)} where R ⊆ A × B
A = {1, 2, 3, 4}, B = {3, 4, 5, 6}

Domain = {1, 2, 3}
Range = {3, 4, 5}
Codomain = {3, 4, 5, 6}
```


***

## **3.3 Types of Relations**[^6]

### **3.3.1 Reflexive Relation**

**Definition:** A relation R on set A is reflexive if **(a, a) ∈ R for all a ∈ A**.

**Example:**

```
A = {1, 2, 3}
R = {(1,1), (2,2), (3,3), (1,2)} → Reflexive ✓
R = {(1,1), (2,2)} → Not reflexive ✗ (missing (3,3))
```


***

### **3.3.2 Symmetric Relation**

**Definition:** R is symmetric if **(a, b) ∈ R implies (b, a) ∈ R**.

**Example:**

```
A = {1, 2, 3}
R = {(1,2), (2,1), (2,3), (3,2)} → Symmetric ✓
R = {(1,2), (2,3)} → Not symmetric ✗
```


***

### **3.3.3 Transitive Relation**

**Definition:** R is transitive if **(a, b) ∈ R and (b, c) ∈ R implies (a, c) ∈ R**.

**Example:**

```
A = {5, 7, 9}
R = {(5,7), (7,9), (5,9)} → Transitive ✓
R = {(5,7), (7,9)} → Not transitive ✗ (missing (5,9))
```


***

### **3.3.4 Equivalence Relation**[^6]

**Definition:** A relation R is an equivalence relation if it is:

1. Reflexive
2. Symmetric
3. Transitive

**Example:**

```
A = {1, 2, 3}
R = {(1,1), (2,2), (3,3), (1,2), (2,1)}
Check:
- Reflexive: ✓ (all (a,a) present)
- Symmetric: ✓ ((1,2) and (2,1) both present)
- Transitive: ✓ (no violation)
→ Equivalence Relation ✓
```


***

### **3.3.5 Antisymmetric Relation**[^6]

**Definition:** R is antisymmetric if **(a, b) ∈ R and (b, a) ∈ R implies a = b**.

**Example:**

```
A = {a, b}
R = {(a, a)} → Antisymmetric ✓
R = {(a, b), (b, a)} → Not antisymmetric ✗ (a ≠ b but both pairs present)
```


***

## **3.4 Functions**[^7]

### **Definition**

A **function** (or **mapping**) f from set A to set B is a rule that associates every element of A with a **unique** element of B.

**Notation:** f: A → B

**Key Terms:**

- **Domain:** Set A
- **Codomain:** Set B
- **Image of x:** If f(x) = y, then y is the image of x
- **Pre-image of y:** x is a pre-image of y if f(x) = y
- **Range:** Set of all images = f(A) = {f(x) | x ∈ A}

**Important:** Range ⊆ Codomain

***

## **3.5 Types of Functions**[^7]

### **3.5.1 One-to-One (Injective) Function**

**Definition:** f: A → B is one-to-one if different elements in A have different images in B.

**Mathematically:** f(x₁) = f(x₂) implies x₁ = x₂

**Example:**

```
f: R → R defined by f(x) = 2x + 5

Check: Suppose f(x₁) = f(x₂)
       2x₁ + 5 = 2x₂ + 5
       2x₁ = 2x₂
       x₁ = x₂
→ One-to-one ✓
```


***

### **3.5.2 Onto (Surjective) Function**

**Definition:** f: A → B is onto if every element in B is the image of at least one element in A.

**Mathematically:** For all y ∈ B, there exists x ∈ A such that f(x) = y

**Equivalently:** Range = Codomain

**Example:**

```
f: R → R defined by f(x) = 2x + 5

For any y ∈ R, we can find x = (y-5)/2 ∈ R such that f(x) = y
→ Onto ✓
```


***

### **3.5.3 Bijective Function (One-to-One Correspondence)**

**Definition:** A function that is both one-to-one AND onto.

**Properties:**

- Every element in B has exactly one pre-image in A
- Inverse function exists

***

### **3.5.4 Into Function**

**Definition:** f: A → B is into if at least one element in B is not the image of any element in A.

**Equivalently:** Range ⊂ Codomain (proper subset)

***

### **3.5.5 Many-to-One Function**

**Definition:** Two or more elements in A have the same image in B.

**Example:** f(x) = x² (both 2 and -2 map to 4)

***

## **3.6 Special Functions**[^7]

### **3.6.1 Identity Function**

**Definition:** I_A: A → A defined by I_A(x) = x for all x ∈ A

**Properties:**

- One-to-one
- Onto
- Bijective

***

### **3.6.2 Inverse Function**[^7]

**Definition:** If f: A → B is bijective, then f⁻¹: B → A is defined by:
f⁻¹(y) = x if and only if f(x) = y

**Properties:**

- f(f⁻¹(y)) = y for all y ∈ B
- f⁻¹(f(x)) = x for all x ∈ A
- (f⁻¹)⁻¹ = f

**Example:**

```
f: R → R defined by f(x) = 2x + 5

To find f⁻¹:
Let y = 2x + 5
x = (y - 5)/2

Therefore f⁻¹(y) = (y - 5)/2
```


***

### **3.6.3 Composite Functions**[^7][^6]

**Definition:** If f: A → B and g: B → C, then the composition g ∘ f: A → C is defined by:
(g ∘ f)(x) = g(f(x))

**Read as:** "g of f of x" or "g circle f"

**Properties:**

- Associative: (h ∘ g) ∘ f = h ∘ (g ∘ f)
- NOT commutative: g ∘ f ≠ f ∘ g (in general)

**Example:**

```
f(x) = x + 1, g(x) = 2x

(g ∘ f)(x) = g(f(x)) = g(x+1) = 2(x+1) = 2x + 2
(f ∘ g)(x) = f(g(x)) = f(2x) = 2x + 1

Note: g ∘ f ≠ f ∘ g
```


***

## **3.7 Pigeonhole Principle**[^6]

### **Statement**

If n pigeons are accommodated in m pigeonholes and n > m, then at least one pigeonhole must contain at least ⌈n/m⌉ pigeons.

**Formula:** ⌈n/m⌉ where ⌈ ⌉ is the ceiling function

### **Solved Examples**

**Example 1:** Prove that in a set of 29 persons, at least 5 persons must have been born on the same day of the week.[^6]

**Solution:**

```
n = 29 (pigeons)
m = 7 (days of week - pigeonholes)

At least ⌈29/7⌉ = ⌈4.14⌉ = 5 persons born on same day ✓
```

**Example 2:** Among 50 people, what is the minimum number of people who must be born in the same month?[^6]

**Solution:**

```
n = 50, m = 12

⌈50/12⌉ = ⌈4.16⌉ = 5 people
```


***

## **3.8 Solved Examples - Relations \& Functions**

### **Example 1:** Find domain and range of R = {(x, y) | x, y ∈ R, x² + y² ≤ 4}

**Solution:**

```
x² + y² ≤ 4 represents interior and boundary of circle with radius 2

Domain: x² ≤ 4 → -2 ≤ x ≤ 2 → [-2, 2]
Range: y² ≤ 4 → -2 ≤ y ≤ 2 → [-2, 2]
```


***

### **Example 2:** Check if f(x) = 3x - 5 is bijective. If yes, find f⁻¹.[^6]

**Solution:**

```
One-to-one check:
Suppose f(x₁) = f(x₂)
3x₁ - 5 = 3x₂ - 5
3x₁ = 3x₂
x₁ = x₂ ✓ One-to-one

Onto check:
For any y ∈ R, x = (y+5)/3 ∈ R such that f(x) = y ✓ Onto

f is bijective ✓

Inverse:
y = 3x - 5
x = (y + 5)/3

f⁻¹(x) = (x + 5)/3
```


***

## **3.9 Quick Review - Module 3**

**Key Formulas:**

1. n(A × B) = n(A) × n(B)
2. Pigeonhole: ⌈n/m⌉
3. For bijective f: (f ∘ f⁻¹)(x) = x

**Top 10 Testable Facts:**

1. Equivalence relation = Reflexive + Symmetric + Transitive
2. Bijective = One-to-one + Onto
3. Only bijective functions have inverses
4. g ∘ f ≠ f ∘ g (not commutative)
5. Cartesian product not commutative
6. Range ⊆ Codomain always
7. Identity function is bijective
8. Antisymmetric: (a,b) and (b,a) in R → a = b
9. Domain of f⁻¹ = Range of f
10. Pigeonhole principle for existence proofs

***

# **MODULE 4: PERMUTATIONS AND COMBINATIONS**

## **4.1 Fundamental Principles of Counting**[^8]

### **4.1.1 Multiplication Principle**

**Statement:** If an operation can be performed in m ways, and for each of these, another operation can be performed in n ways, then the two operations together can be performed in **m × n** ways.

**Example:**

```
If you have 3 shirts and 4 pants, number of outfits = 3 × 4 = 12
```


***

### **4.1.2 Addition Principle**

**Statement:** If an operation can be performed in m ways and another mutually exclusive operation in n ways, then either operation can be performed in **m + n** ways.

**Example:**

```
Travel from A to B: 3 bus routes OR 2 train routes
Total ways = 3 + 2 = 5
```


***

## **4.2 Factorial Notation**[^8]

**Definition:** n! (n factorial) = n × (n-1) × (n-2) × ... × 3 × 2 × 1

**Special Cases:**

- 0! = 1 (by definition)
- 1! = 1

**Examples:**

- 5! = 5 × 4 × 3 × 2 × 1 = 120
- 6! = 6 × 5! = 720

***

## **4.3 Permutations**[^8]

### **Definition**

A **permutation** is an arrangement of objects in a definite order. **Order matters** in permutations.

### **4.3.1 Permutations of n Distinct Objects**

**Formula:** ⁿPᵣ = n!/(n-r)! where r ≤ n

**Special Case:** ⁿPₙ = n!

**Example:**

```
Number of ways to arrange 3 books from 5 different books:
⁵P₃ = 5!/(5-3)! = 5!/2! = 120/2 = 60
```


***

### **4.3.2 Permutations with Repetition**[^8]

If n objects include p identical objects of one type, q identical of another, and so on:

**Formula:** n!/(p! × q! × r! × ...)

**Example:**

```
Arrangements of letters in "TALLAHASSEE":
11 letters: 2 L's, 2 S's, 2 E's, 3 A's, 1 T, 1 H

Number of arrangements = 11!/(2! × 2! × 2! × 3!)
= 39,916,800/(2 × 2 × 2 × 6)
= 39,916,800/24
= 1,663,200
```


***

### **4.3.3 Circular Permutations**[^8]

**Formula:** (n-1)! for arranging n distinct objects in a circle

**Explanation:** Fix one object and arrange the rest.

**If clockwise and anticlockwise are same:** (n-1)!/2

**Example:**

```
Ways to seat 5 people around a circular table = (5-1)! = 4! = 24
```


***

## **4.4 Combinations**[^8]

### **Definition**

A **combination** is a selection of objects where **order does NOT matter**.

### **Formula**

ⁿCᵣ = n!/(r!(n-r)!) where r ≤ n

**Alternative Notation:** (n choose r) or C(n,r)

**Example:**

```
Select 3 books from 5 different books:
⁵C₃ = 5!/(3! × 2!) = 120/(6 × 2) = 10
```


***

### **4.4.1 Properties of Combinations**[^8]

1. **ⁿCᵣ = ⁿCₙ₋ᵣ**
2. **ⁿC₀ = ⁿCₙ = 1**
3. **ⁿCᵣ + ⁿCᵣ₋₁ = ⁿ⁺¹Cᵣ** (Pascal's Identity)
4. **ⁿC₁ = n**

***

## **4.5 Combinations with Repetitions**[^9]

### **Formula**

Number of ways to select r objects from n distinct objects with repetition allowed:

**ⁿ⁺ʳ⁻¹Cᵣ = (n+r-1)!/(r!(n-1)!)**

**Alternative Interpretation:** Number of ways to distribute r identical objects among n distinct containers.

**Example:**

```
Number of ways to distribute 10 identical marbles among 6 distinct containers:
¹⁰⁺⁶⁻¹C₁₀ = ¹⁵C₁₀ = ¹⁵C₅ = 3003
```


***

## **4.6 Binomial Theorem**[^9]

### **Statement**

For any positive integer n:

**(x + y)ⁿ = ⁿC₀xⁿ + ⁿC₁xⁿ⁻¹y + ⁿC₂xⁿ⁻²y² + ... + ⁿCₙyⁿ**

**General Term:** Tᵣ₊₁ = ⁿCᵣxⁿ⁻ʳyʳ (r+1)th term

### **Properties**[^9]

1. Number of terms = n + 1
2. Sum of exponents in each term = n
3. Coefficients are symmetric: ⁿC₀ = ⁿCₙ, ⁿC₁ = ⁿCₙ₋₁, etc.
4. Sum of coefficients: Put x = y = 1 → 2ⁿ

**Example:**

```
Expand (2x - 3y)⁵

T₁ = ⁵C₀(2x)⁵ = 32x⁵
T₂ = ⁵C₁(2x)⁴(-3y) = 5 × 16x⁴ × (-3y) = -240x⁴y
T₃ = ⁵C₂(2x)³(-3y)² = 10 × 8x³ × 9y² = 720x³y²
...and so on
```


***

## **4.7 Catalan Numbers**[^9]

### **Definition**

The **Catalan sequence** is defined by:

- b₀ = 1
- bₙ = ²ⁿCₙ/(n+1)

**Alternative Formula:** bₙ = (2n)!/(n!(n+1)!)

### **First Few Catalan Numbers**[^9]

```
b₀ = 1
b₁ = ²C₁/2 = 1
b₂ = ⁴C₂/3 = 6/3 = 2
b₃ = ⁶C₃/4 = 20/4 = 5
b₄ = ⁸C₄/5 = 70/5 = 14
b₅ = ¹⁰C₅/6 = 252/6 = 42
```

**Sequence:** 1, 1, 2, 5, 14, 42, ...

### **Applications**

- Number of ways to parenthesize expressions
- Number of binary trees with n nodes
- Number of paths in grids that don't cross diagonal

***

## **4.8 Solved Examples - Permutations \& Combinations**

### **Example 1:** If ⁿC₆ = ⁿC₁₄, find n.[^9]

**Solution:**

```
Using property: ⁿCᵣ = ⁿCₙ₋ᵣ

ⁿC₆ = ⁿC₁₄ implies n - 6 = 14
Therefore n = 20

OR 6 = 14 (not possible)

Answer: n = 20
```


***

### **Example 2:** If ⁿCᵣ = 120 and ⁿPᵣ = 240, find n and r.[^9]

**Solution:**

```
We know: ⁿPᵣ = r! × ⁿCᵣ

240 = r! × 120
r! = 2
r = 2 ✓

Now ⁿC₂ = 120
n!/(2!(n-2)!) = 120
n(n-1)/2 = 120
n² - n = 240
n² - n - 240 = 0
(n-16)(n+15) = 0
n = 16 (n > 0)

Answer: n = 16, r = 2
```


***

### **Example 3:** Find the number of triangles that can be formed from 12 points in a plane, of which 4 are collinear.[^9]

**Solution:**

```
If no points collinear: ¹²C₃ = 220 triangles

But 4 collinear points cannot form a triangle.
Invalid combinations: ⁴C₃ = 4

Valid triangles = 220 - 4 = 216
```


***

### **Example 4:** In how many ways can we distribute 12 identical pencils to 5 children so that each child gets at least 1 pencil?[^9]

**Solution:**

```
First give 1 pencil to each child: 5 pencils distributed
Remaining: 12 - 5 = 7 pencils

Distribute 7 identical pencils among 5 children:
⁷⁺⁵⁻¹C₇ = ¹¹C₇ = ¹¹C₄ = 330 ways
```


***

### **Example 5:** Find the coefficient of x³y⁹ in the expansion of (2x - 3y)¹².[^9]

**Solution:**

```
General term: Tᵣ₊₁ = ¹²Cᵣ(2x)¹²⁻ʳ(-3y)ʳ

For x³y⁹: 
Power of x: 12 - r = 3 → r = 9
Power of y: r = 9 ✓

T₁₀ = ¹²C₉(2x)³(-3y)⁹
    = (220)(8x³)(-19683y⁹)
    = -34,680,960x³y⁹

Coefficient = -34,680,960
```


***

## **4.9 Common Mistakes**

❌ **Mistake 1:** Using permutation when combination is needed (or vice versa)

- Remember: Order matters → Permutation; Order doesn't matter → Combination

❌ **Mistake 2:** Forgetting to account for identical objects in permutations

- Must divide by factorial of repetitions

❌ **Mistake 3:** Confusing ⁿPᵣ with ⁿCᵣ formulas

- ⁿPᵣ = n!/(n-r)! vs ⁿCᵣ = n!/(r!(n-r)!)

❌ **Mistake 4:** Not adjusting for restrictions (like "at least one")

- Use complementary counting or adjust formula

***

## **4.10 Quick Review - Module 4**

**Key Formulas:**

1. ⁿPᵣ = n!/(n-r)!
2. ⁿCᵣ = n!/(r!(n-r)!)
3. Combinations with repetition: ⁿ⁺ʳ⁻¹Cᵣ
4. Catalan number: bₙ = ²ⁿCₙ/(n+1)
5. Circular permutations: (n-1)!

**Top 10 Testable Facts:**

1. 0! = 1 by definition
2. ⁿCᵣ = ⁿCₙ₋ᵣ
3. ⁿPᵣ = r! × ⁿCᵣ
4. Permutations with repetition: n!/(p!q!r!...)
5. Circular permutation: (n-1)!
6. Binomial theorem general term
7. Sum of binomial coefficients = 2ⁿ
8. Pigeonhole principle formula
9. Combinations with repetition for distribution problems
10. Pascal's identity: ⁿCᵣ + ⁿCᵣ₋₁ = ⁿ⁺¹Cᵣ

***

# **ULTIMATE CHEAT SHEET**

## **Set Theory - Quick Reference**

```
• Power Set: n(P(A)) = 2ⁿ
• De Morgan's: (A∪B)' = A'∩B', (A∩B)' = A'∪B'
• Difference: A - B = A ∩ B'
• A ∪ A' = U, A ∩ A' = ∅
```


## **Logic - Quick Reference**

```
• Tautology: Always True (p ∨ ¬p)
• Contradiction: Always False (p ∧ ¬p)
• Implication: p → q ≡ ¬p ∨ q
• Contrapositive: p → q ≡ ¬q → ¬p
• De Morgan's: ¬(p∧q) ≡ ¬p∨¬q, ¬(p∨q) ≡ ¬p∧¬q
```


## **Relations \& Functions - Quick Reference**

```
• n(A × B) = n(A) × n(B)
• Equivalence = Reflexive + Symmetric + Transitive
• Bijective = One-to-one + Onto
• Only bijective functions have inverses
• Pigeonhole: ⌈n/m⌉
```


## **Permutations \& Combinations - Quick Reference**

```
• ⁿPᵣ = n!/(n-r)!
• ⁿCᵣ = n!/(r!(n-r)!)
• With repetition: (n+r-1)!/(r!(n-1)!)
• Circular: (n-1)!
• ⁿCᵣ = ⁿCₙ₋ᵣ
```


***

# **PRACTICE MINI QUIZ**

## **Module 1 - Sets**

1. If A = {1,2,3}, find n(P(A))
2. Verify: (A ∪ B)' = A' ∩ B' for A={1,2}, B={2,3}, U={1,2,3,4}
3. Simplify: A - (A - B)
4. If n(A) = 5, n(B) = 3, n(A∩B) = 2, find n(A∪B)

**Answers:**

1. 2³ = 8
2. LHS: (A∪B)'={4}, RHS: A'∩B'={4,3}∩{1,4}={4} ✓
3. A ∩ B
4. 5 + 3 - 2 = 6

## **Module 2 - Logic**

1. Construct truth table for (p → q) ∧ (q → r)
2. Is p ∨ ¬p a tautology or contradiction?
3. Write contrapositive of: "If it rains, I carry umbrella"
4. Simplify: ¬(p ∧ q) ∨ p

**Answers:**

1. [8-row table needed]
2. Tautology
3. "If I don't carry umbrella, it doesn't rain"
4. ¬q ∨ p or p → ¬q

## **Module 3 - Relations \& Functions**

1. Is f(x) = x² one-to-one? Onto (R → R)?
2. If f(x) = 3x + 1, find f⁻¹(x)
3. Among 30 students, minimum born in same month?
4. Check if R = {(1,1),(2,2),(1,2),(2,1)} is equivalence on {1,2}

**Answers:**

1. Not one-to-one (f(2)=f(-2)=4), Not onto (no pre-image for -1)
2. f⁻¹(x) = (x-1)/3
3. ⌈30/12⌉ = 3
4. Yes (Reflexive, Symmetric, Transitive all satisfied)

## **Module 4 - Permutations \& Combinations**

1. Calculate ⁷P₃
2. Find ⁸C₅
3. Ways to distribute 5 identical books to 3 students?
4. Find coefficient of x⁴ in (x + 2)⁶

**Answers:**

1. 7!/(7-3)! = 7×6×5 = 210
2. ⁸C₅ = ⁸C₃ = 56
3. ⁵⁺³⁻¹C₅ = ⁷C₅ = 21
4. ⁶C₄(2)² = 15×4 = 60

***

**References:**

- Schaum's Outline of Discrete Mathematics (3rd Edition)[^10]
- Kenneth H. Rosen - Discrete Mathematics and Its Applications[^4]
- Course lecture notes and materials[^7][^6][^3][^1][^2]

***

**Study Tips:**

1. Practice drawing Venn diagrams for set problems
2. Create truth tables systematically for logic problems
3. Always check all three properties for equivalence relations
4. Identify whether order matters before choosing P or C
5. Use pigeonhole principle for existence proofs
6. Verify bijective before finding inverse functions

**Good Luck with Your Exams! 🎓**
<span style="display:none">[^11][^12][^13][^14][^15][^16][^17][^18]</span>

<div align="center">⁂</div>

[^1]: Sets-1.pdf

[^2]: Sets-2.pdf

[^3]: Logic-1.pdf

[^4]: Textbook.pdf

[^5]: Problems-on-Propositional-Logic.pdf

[^6]: Khushi-Krishna-Relations-and-Functions-Notes-DMST.pdf

[^7]: Functions-Theory-Definitions.pdf

[^8]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/a7480297-85db-4b31-af24-fe366f8cc84f/Permutations-and-combinations.pdf

[^9]: Combinations-with-repetitions-Binomial-theorem-Catalan-numbers.pdf

[^10]: Textbook2.pdf

[^11]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/1c805458-376e-4013-926a-9452ead78b97/Permutations-and-Combinations-complete-notes.pdf

[^12]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/9501e3b3-bd40-4c48-b49f-219787eeae02/COMBINATIONS-WITH-REPETITIONS-example.docx

[^13]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/ecd48d81-6978-43ef-8489-e53df659e216/Logic-practice-questions.pdf

[^14]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/cb82be88-9e3a-419f-aadb-2660d5322849/PQ-Sets-2-.pdf.pdf

[^15]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/b7a4e9c5-4dd5-4ea2-b61e-e59e76ad3841/Problems-on-logic.pdf

[^16]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/61947ca8-1d21-4814-b963-89bd359cc53b/Logic-2.pdf

[^17]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/da6633a4-4d8a-4830-9268-b4a3b534b589/PQ-Sets-1.pdf

[^18]: https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/7890236/7cf5ca53-585b-487a-aedd-7ca3f793004a/Problems-Sets-2.pdf

