# Complete Discrete Mathematics Study Notes
## Computer Science - First Year, RV University

**Course Code**: CS1812 - Discrete Mathematics & Set Theory

### Summary
These comprehensive notes cover fundamental topics in Discrete Mathematics including Permutations and Combinations, Sets, and Propositional Logic. The material focuses on counting principles, arrangement and selection techniques, set operations and properties, and logical reasoning. These topics form the mathematical foundation for computer science, with applications in algorithms, data structures, probability, and computational theory. Master these concepts to excel in both theoretical understanding and problem-solving.

---

# MODULE 1: PERMUTATIONS AND COMBINATIONS

## Learning Objectives
- Understand and apply fundamental counting principles
- Master permutation and combination formulas
- Solve complex arrangement and selection problems
- Apply binomial theorem and understand Catalan numbers
- Develop problem-solving strategies for competitive exams

---

## UNIT 1.1: Fundamental Counting Principles

### 1.1.1 The Multiplication Principle (Product Rule)

**Definition**: If a task T₁ can be performed in *m* different ways, and for each way of performing T₁, another task T₂ can be performed in *n* different ways, then the total number of ways to perform both tasks in sequence is **m × n**.

**Detailed Explanation**:
The multiplication principle applies when:
- Tasks must be performed in sequence (one after another)
- Each task is independent of the other
- Both tasks must be completed

**Mathematical Notation**: If task T₁ has *m* outcomes and task T₂ has *n* outcomes (for each outcome of T₁), then:
```
Total outcomes = m × n
```

**Extended Form**: For multiple tasks T₁, T₂, T₃, ..., Tₖ:
```
Total outcomes = n₁ × n₂ × n₃ × ... × nₖ
```

**Examples**:

**Example 1**: A person has 8 shirts and 5 ties. How many different combinations of shirt and tie can they wear?
- **Solution**: 
  - Ways to choose a shirt = 8
  - Ways to choose a tie = 5
  - Total combinations = 8 × 5 = **40 ways**

**Example 2**: How many 4-symbol sequences can be constructed where:
- First two symbols are letters (a-z)
- Last two symbols are digits (0-9)
- Repetitions are allowed

- **Solution**:
  - First position: 26 ways
  - Second position: 26 ways
  - Third position: 10 ways
  - Fourth position: 10 ways
  - Total = 26 × 26 × 10 × 10 = **67,600 sequences**

**Example 3**: A license plate consists of 3 letters followed by 4 digits. If repetitions are allowed, how many plates have only vowels (A, E, I, O, U) and even digits?
- **Solution**:
  - Vowels available: 5
  - Even digits (0,2,4,6,8): 5
  - Total = 5 × 5 × 5 × 5 × 5 × 5 × 5 = 5⁷ = **78,125 plates**

---

### 1.1.2 The Addition Principle (Sum Rule)

**Definition**: If a task can be performed in *m* ways OR another task can be performed in *n* ways, and the two tasks **cannot be done simultaneously**, then either task can be performed in **m + n** ways.

**Key Condition**: The tasks must be **mutually exclusive** (cannot occur together).

**Mathematical Notation**: If event E₁ can occur in *m* ways and event E₂ can occur in *n* ways (and they cannot both occur), then:
```
Total ways = m + n
```

**Examples**:

**Example 1**: A class has 16 boys and 18 girls. In how many ways can we select one student to be class representative?
- **Solution**:
  - Ways to select a boy = 16
  - Ways to select a girl = 18
  - Total ways = 16 + 18 = **34 ways**
  - (We select either a boy OR a girl, not both)

**Example 2**: A library has 10 books on Physics, 16 books on Chemistry, and 11 books on Electronics. A student wishes to choose one book. In how many ways can the selection be made?
- **Solution**:
  - Total ways = 10 + 16 + 11 = **37 ways**

**Example 3**: Suppose there are 3 routes from City A to City B and 4 routes from City A to City C. In how many ways can a person travel from City A to either City B or City C?
- **Solution**:
  - Total ways = 3 + 4 = **7 ways**

---

### 1.1.3 Combined Application of Both Principles

**Example 1**: In how many ways can a student select a program of 5 courses if 2 specific courses are compulsory for all students and 3 courses are to be selected from 8 available electives?
- **Solution**:
  - Compulsory courses: Already fixed (1 way)
  - Selecting 3 from 8 electives: ₈C₃ = 56 ways
  - Total = **56 ways**

**Example 2**: How many 8-bit binary strings begin with 1 and end with 1?
- **Solution**:
  - First bit: Fixed as 1 (1 way)
  - Middle 6 bits: Each can be 0 or 1 (2⁶ = 64 ways)
  - Last bit: Fixed as 1 (1 way)
  - Total = 1 × 2⁶ × 1 = **64 strings**

**Example 3**: How many 8-bit strings begin with 1 OR end with 1?
- **Solution**:
  - Strings beginning with 1: 2⁷ = 128
  - Strings ending with 1: 2⁷ = 128
  - Strings beginning AND ending with 1: 2⁶ = 64
  - Using inclusion-exclusion: 128 + 128 - 64 = **192 strings**

---

### Common Mistakes and Misconceptions

| Mistake | Correct Approach |
|---------|------------------|
| Using addition when multiplication is needed | Use multiplication for sequential tasks |
| Using multiplication when addition is needed | Use addition for mutually exclusive choices |
| Forgetting about overlap in OR situations | Apply inclusion-exclusion principle |
| Not checking if events are independent | Verify independence before using product rule |

---

### Practice Questions

**Q1**: A restaurant menu has 5 appetizers, 8 main courses, and 4 desserts. How many different three-course meals can be ordered?
<details>
<summary>Answer</summary>
5 × 8 × 4 = 160 meals
</details>

**Q2**: In how many ways can you answer a 10-question true/false exam?
<details>
<summary>Answer</summary>
2¹⁰ = 1024 ways
</details>

**Q3**: How many 3-digit numbers can be formed using digits 1-9 without repetition?
<details>
<summary>Answer</summary>
9 × 8 × 7 = 504 numbers
</details>

---

### Quick Review Summary
- **Multiplication Principle**: Use when tasks are sequential and all must be performed (AND situation)
- **Addition Principle**: Use when tasks are mutually exclusive alternatives (OR situation)
- Always identify whether events can occur together or not
- For complex problems, break down into smaller sequential or alternative tasks

---

## UNIT 1.2: PERMUTATIONS

### 1.2.1 Introduction to Permutations

**Definition**: A **permutation** is an arrangement of objects in a definite order. The order of arrangement matters in permutations.

**Key Concept**: Permutations answer the question: "In how many ways can we **arrange** these objects?"

**Distinction**:
- **Arrangement matters**: ABC ≠ BAC ≠ CAB
- Each different ordering counts as a separate permutation

---

### 1.2.2 Factorial Notation

**Definition**: The factorial of a positive integer *n*, denoted **n!**, is the product of all positive integers from 1 to *n*.

**Formula**:
```
n! = n × (n-1) × (n-2) × ... × 3 × 2 × 1
```

**Special Cases**:
- **0! = 1** (by definition)
- **1! = 1**

**Examples**:
- 3! = 3 × 2 × 1 = 6
- 5! = 5 × 4 × 3 × 2 × 1 = 120
- 10! = 3,628,800

**Properties**:
1. n! = n × (n-1)!
2. n! grows very rapidly
3. n! > 2ⁿ for n ≥ 4

---

### 1.2.3 Permutations of n Distinct Objects Taken All at a Time

**Formula**: The number of permutations of *n* distinct objects taken all at a time is:
```
ⁿPₙ = n!
```

**Derivation**:
- First position: *n* choices
- Second position: *(n-1)* choices
- Third position: *(n-2)* choices
- ...
- Last position: 1 choice
- Total = n × (n-1) × (n-2) × ... × 1 = n!

**Examples**:

**Example 1**: In how many ways can 5 people be arranged in a row?
- **Solution**: ⁵P₅ = 5! = **120 ways**

**Example 2**: How many different 4-letter "words" can be formed using the letters A, B, C, D (each used exactly once)?
- **Solution**: ⁴P₄ = 4! = **24 words**

---

### 1.2.4 Permutations of n Distinct Objects Taken r at a Time

**Formula**: The number of permutations of *n* distinct objects taken *r* at a time (where 0 < r ≤ n) is:
```
ⁿPᵣ = n!/(n-r)!
```

**Alternative Formula**:
```
ⁿPᵣ = n × (n-1) × (n-2) × ... × (n-r+1)  [r terms]
```

**Derivation**:
- First position: *n* choices
- Second position: *(n-1)* choices
- ...
- r-th position: *(n-r+1)* choices
- Total = n × (n-1) × ... × (n-r+1) = n!/(n-r)!

**Examples**:

**Example 1**: In how many ways can we select and arrange 3 books from 10 different books?
- **Solution**: 
  - ¹⁰P₃ = 10!/(10-3)! = 10!/7! = 10 × 9 × 8 = **720 ways**

**Example 2**: How many 3-digit numbers can be formed using the digits 1, 2, 3, 4, 5, 6, 7 without repetition?
- **Solution**:
  - ⁷P₃ = 7!/(7-3)! = 7 × 6 × 5 = **210 numbers**

**Example 3**: In how many ways can a president, vice-president, and secretary be chosen from 12 people?
- **Solution**:
  - ¹²P₃ = 12 × 11 × 10 = **1,320 ways**

---

### 1.2.5 Permutations with Repetition Allowed

**Case 1: All objects taken, repetition allowed**

**Formula**: The number of permutations of *n* distinct things taken all at a time, when repetition is allowed, is:
```
nⁿ
```

**Example**: How many 5-letter "words" can be formed using the 26 English letters if repetition is allowed?
- **Solution**: 26⁵ = **11,881,376 words**

---

**Case 2: r objects taken from n, repetition allowed**

**Formula**: The number of permutations of *n* objects taken *r* at a time, when repetition is allowed, is:
```
nʳ
```

**Examples**:

**Example 1**: How many 4-digit numbers can be formed using digits 0-9 if repetition is allowed?
- **Solution**: 
  - First digit: 9 choices (1-9, cannot be 0)
  - Remaining digits: 10 choices each
  - Total = 9 × 10³ = **9,000 numbers**

**Example 2**: How many 3-letter "words" can be formed using vowels {A, E, I, O, U} if repetition is allowed?
- **Solution**: 5³ = **125 words**

---

### 1.2.6 Permutations of Objects with Some Identical

**Formula**: The number of permutations of *n* objects where:
- p₁ objects are of one kind
- p₂ objects are of a second kind
- ...
- pₖ objects are of k-th kind
- The rest (if any) are all different

is given by:
```
n! / (p₁! × p₂! × ... × pₖ!)
```

**Explanation**: We divide by the factorials of identical objects to eliminate counting duplicate arrangements.

**Examples**:

**Example 1**: How many distinct strings can be formed using all letters of "MISSISSIPPI"?
- **Solution**:
  - Total letters: 11
  - M: 1, I: 4, S: 4, P: 2
  - Answer = 11! / (1! × 4! × 4! × 2!) = **34,650 strings**

**Example 2**: How many distinct strings can be formed using the letters of "FLOWER"?
- **Solution**:
  - All letters are distinct
  - Answer = 6! = **720 strings**

**Example 3**: How many distinct arrangements of "SUCCESS"?
- **Solution**:
  - Total: 7 letters
  - S: 3, U: 1, C: 2, E: 1
  - Answer = 7! / (3! × 2!) = **420 arrangements**

**Example 4**: In how many ways can the letters of "CORRESPONDENTS" be arranged?
- **Solution**:
  - Total: 14 letters
  - C: 1, O: 2, R: 2, E: 2, S: 2, P: 1, N: 2, D: 1, T: 1
  - Answer = 14! / (2! × 2! × 2! × 2! × 2!) = **1,816,214,400 arrangements**

---

### 1.2.7 Circular Permutations

**Formula**: The number of ways *n* distinct objects can be arranged around a circle is:
```
(n-1)!
```

**Explanation**: 
- In circular arrangements, there is no fixed starting point
- We fix one object to remove rotational duplicates
- Remaining (n-1) objects can be arranged in (n-1)! ways

**Examples**:

**Example 1**: In how many ways can 6 people be seated around a circular table?
- **Solution**: (6-1)! = 5! = **120 ways**

**Example 2**: In how many ways can 5 men and 4 women be seated around a circular table such that no two women sit together?
- **Solution**:
  - Arrange 5 men in a circle: 4! = 24 ways
  - 5 gaps are created between men
  - Arrange 4 women in 5 gaps: ⁵P₄ = 120 ways
  - Total = 24 × 120 = **2,880 ways**

---

### 1.2.8 Special Permutation Cases

**Case 1: Specific objects always together**

**Method**: Treat the specific objects as a single unit.

**Example**: In how many ways can 5 children be arranged in a line such that 2 particular children are always together?
- **Solution**:
  - Consider 2 particular children as 1 unit
  - Now we have 4 units to arrange: 4! = 24 ways
  - The 2 children within the unit can be arranged: 2! = 2 ways
  - Total = 24 × 2 = **48 ways**

---

**Case 2: Specific objects never together**

**Method**: Total arrangements - Arrangements where they are together

**Example**: In how many ways can 5 children be arranged such that 2 particular children are never together?
- **Solution**:
  - Total arrangements: 5! = 120
  - Arrangements where they are together: 48 (from above)
  - Answer = 120 - 48 = **72 ways**

---

**Case 3: Arrangements with restrictions**

**Example**: How many arrangements of "RACHIT" are there if it must start with R and end with T?
- **Solution**:
  - First position: R (fixed)
  - Last position: T (fixed)
  - Middle 4 letters (A, C, H, I): 4! = **24 arrangements**

---

### Comparison Table: Permutations vs Arrangements

| Aspect | With Repetition | Without Repetition | With Identical Objects |
|--------|----------------|-------------------|----------------------|
| Formula | nʳ | n!/(n-r)! | n!/(p₁!×p₂!×...×pₖ!) |
| Example | 10³ for 3-digit codes | ⁸P₃ for top 3 winners | 7!/(3!×2!) for SUCCESS |
| Use Case | Passwords, codes | Races, rankings | Words with repeated letters |

---

### Practice Questions - Permutations

**Q1**: In how many ways can the letters of "MATHEMATICS" be arranged?
<details>
<summary>Answer</summary>
11!/(2!×2!×2!) = 4,989,600 ways
(M: 2, A: 2, T: 2, rest are unique)
</details>

**Q2**: Find the number of permutations of 7 objects taken 3 at a time such that 2 specific objects always occur together.
<details>
<summary>Answer</summary>
Treat 2 specific objects as 1 unit. Now select 1 more from remaining 5.
Selection: ⁵C₁ = 5
Arrangements: Bundle can be arranged in 2! ways, and the 3 units in 3! ways
Total = 5 × 2 × 6 = 60 ways
</details>

**Q3**: How many 5-digit numbers divisible by 5 can be formed using digits 0-9 without repetition?
<details>
<summary>Answer</summary>
Last digit must be 0 or 5 (2 cases)
Case 1: Ends with 0: 9×8×7×6 = 3024
Case 2: Ends with 5: 8×8×7×6 = 2688 (first digit ≠ 0,5)
Total = 3024 + 2688 = 5712 numbers
</details>

---

### Quick Review Summary - Permutations
- **ⁿPₙ = n!**: All n objects arranged
- **ⁿPᵣ = n!/(n-r)!**: r objects from n arranged
- **nʳ**: Permutations with repetition
- **n!/(p₁!×p₂!×...)**: Permutations with identical objects
- **(n-1)!**: Circular permutations
- **Together/Apart**: Use unit method or subtraction

---

## UNIT 1.3: COMBINATIONS

### 1.3.1 Introduction to Combinations

**Definition**: A **combination** is a selection of objects from a set where the **order does not matter**. We're interested only in which objects are selected, not how they are arranged.

**Key Distinction**:

| Permutations | Combinations |
|-------------|-------------|
| Order matters | Order doesn't matter |
| ABC ≠ BAC | {A,B,C} = {B,A,C} |
| Arrangements | Selections |
| ⁿPᵣ = n!/(n-r)! | ⁿCᵣ = n!/[r!(n-r)!] |

**Example**: Selecting 3 students from 10 for a committee
- Who is selected matters
- The order of selection doesn't matter
- {A,B,C} is the same committee as {C,A,B}

---

### 1.3.2 Combination Formula

**Formula**: The number of combinations of *n* distinct objects taken *r* at a time is:
```
ⁿCᵣ = n! / [r! × (n-r)!]
```

**Alternative Notations**:
- ⁿCᵣ
- C(n,r)
- (n choose r) or ⁿ�r

**Relationship with Permutations**:
```
ⁿCᵣ = ⁿPᵣ / r!
```

**Explanation**: Each combination of *r* objects can be arranged in r! ways, so:
```
ⁿPᵣ = ⁿCᵣ × r!
```

---

### 1.3.3 Properties of Combinations

**Property 1**: **Symmetry**
```
ⁿCᵣ = ⁿCₙ₋ᵣ
```
*Selecting r objects is equivalent to leaving (n-r) objects*

**Example**: ⁵C₂ = ⁵C₃ = 10

---

**Property 2**: **Pascal's Identity**
```
ⁿCᵣ + ⁿCᵣ₋₁ = ⁿ⁺¹Cᵣ
```

**Example**: ⁵C₃ + ⁵C₂ = 10 + 10 = 20 = ⁶C₃

---

**Property 3**: **Sum of all combinations**
```
ⁿC₀ + ⁿC₁ + ⁿC₂ + ... + ⁿCₙ = 2ⁿ
```

**Example**: For n=3: ³C₀ + ³C₁ + ³C₂ + ³C₃ = 1+3+3+1 = 8 = 2³

---

**Property 4**: **Special Values**
```
ⁿC₀ = 1 (select nothing)
ⁿC₁ = n (select one object)
ⁿCₙ = 1 (select all objects)
```

---

**Property 5**: **Multiplication Formula**
```
ⁿCᵣ = (n/r) × ⁿ⁻¹Cᵣ₋₁
```

**Example**: ⁵C₃ = (5/3) × ⁴C₂ = (5/3) × 6 = 10

---

### 1.3.4 Basic Combination Problems

**Example 1**: From 7 men and 5 women, a committee of 3 men and 2 women is to be formed. In how many ways can this be done?
- **Solution**:
  - Select 3 men from 7: ⁷C₃ = 35
  - Select 2 women from 5: ⁵C₂ = 10
  - Total = 35 × 10 = **350 ways**

**Example 2**: In how many ways can a committee of 5 persons be selected from 12 persons?
- **Solution**: ¹²C₅ = 12!/(5!×7!) = **792 ways**

**Example 3**: Out of 5 men and 2 women, a committee of 3 is to be formed. In how many ways can it be formed if at least one woman is to be included?
- **Solution**:
  - Method 1 (Direct):
    - 1 woman, 2 men: ²C₁ × ⁵C₂ = 2 × 10 = 20
    - 2 women, 1 man: ²C₂ × ⁵C₁ = 1 × 5 = 5
    - Total = 20 + 5 = **25 ways**
  
  - Method 2 (Complementary):
    - Total committees: ⁷C₃ = 35
    - All-men committees: ⁵C₃ = 10
    - At least one woman = 35 - 10 = **25 ways**

---

### 1.3.5 Combinations with Restrictions

**Type 1: At Least / At Most Conditions**

**Example**: A student has to answer 7 questions out of 12 questions divided into two groups (6 questions each). He cannot attempt more than 5 from either group. Find the number of ways.
- **Solution**:
  - Possible distributions:
    - 4 from Group A, 3 from Group B: ⁶C₄ × ⁶C₃ = 15 × 20 = 300
    - 5 from Group A, 2 from Group B: ⁶C₅ × ⁶C₂ = 6 × 15 = 90
    - 3 from Group A, 4 from Group B: ⁶C₃ × ⁶C₄ = 20 × 15 = 300
    - 2 from Group A, 5 from Group B: ⁶C₂ × ⁶C₅ = 15 × 6 = 90
  - Total = 300 + 90 + 300 + 90 = **780 ways**

---

**Type 2: Inclusion/Exclusion of Specific Objects**

**Example 1**: How many committees of 5 can be formed from 12 persons if a particular person must be included?
- **Solution**:
  - Fix the particular person (1 way)
  - Select 4 more from remaining 11: ¹¹C₄ = **330 ways**

**Example 2**: How many committees of 5 can be formed from 12 persons if a particular person must be excluded?
- **Solution**:
  - Select 5 from remaining 11: ¹¹C₅ = **462 ways**

**Example 3**: From 8 books, in how many ways can a boy borrow 3 books if he doesn't want to borrow Mathematics Part II unless Mathematics Part I is also borrowed?
- **Solution**:
  - Case 1: Both Math books borrowed: ⁶C₁ = 6
  - Case 2: Math Part II not borrowed: ⁷C₃ = 35
  - Total = 6 + 35 = **41 ways**

---

### 1.3.6 Combinations with Repetition

**Formula**: The number of ways to select *r* objects from *n* distinct types of objects with repetition allowed is:
```
C(n+r-1, r) = (n+r-1)! / [r! × (n-1)!]
```

**Alternative Formula**:
```
C(n+r-1, n-1)
```

**Mnemonic**: "Stars and Bars" method
- r stars represent objects to be selected
- (n-1) bars divide stars into n groups

**Examples**:

**Example 1**: How many ways can 5 pieces of fruit be selected from apples, oranges, and pears if at least 4 of each type are available?
- **Solution**:
  - n = 3 types, r = 5 pieces
  - Answer = C(3+5-1, 5) = C(7, 5) = **21 ways**

**Verification by listing**:
```
(5,0,0), (4,1,0), (4,0,1), (3,2,0), (3,1,1), (3,0,2),
(2,3,0), (2,2,1), (2,1,2), (2,0,3), (1,4,0), (1,3,1),
(1,2,2), (1,1,3), (1,0,4), (0,5,0), (0,4,1), (0,3,2),
(0,2,3), (0,1,4), (0,0,5)
Total = 21 ✓
```

**Example 2**: In how many ways can 12 identical items be distributed among 6 persons?
- **Solution**:
  - n = 6 persons, r = 12 items
  - Answer = C(6+12-1, 12) = C(17, 12) = **6,188 ways**

**Example 3**: Find the number of non-negative integer solutions to:
```
x₁ + x₂ + x₃ = 10
```
- **Solution**:
  - n = 3 variables, r = 10 (sum)
  - Answer = C(3+10-1, 10) = C(12, 10) = **66 solutions**

---

### 1.3.7 Distributing Identical Objects

**Problem Type**: Distributing *n* identical objects to *r* distinct containers

**Formula**:
```
C(n+r-1, r-1) = C(n+r-1, n)
```

**With Minimum Requirements**:
If each container must get at least *k* objects:
1. Give *k* objects to each container first
2. Distribute remaining (n - kr) objects freely
3. Answer = C(n-kr+r-1, r-1)

**Examples**:

**Example 1**: In how many ways can 12 identical gifts be distributed to 6 children so that each child gets at least one gift?
- **Solution**:
  - First give 1 gift to each: 6 gifts used
  - Remaining: 12 - 6 = 6 gifts
  - Distribute 6 gifts among 6 children: C(6+6-1, 6-1) = C(11, 5) = **462 ways**

**Example 2**: Find the number of solutions to x₁ + x₂ + x₃ + x₄ = 20 where each xᵢ ≥ 3.
- **Solution**:
  - Give 3 to each variable: 12 used
  - Remaining: 20 - 12 = 8
  - Answer = C(8+4-1, 4-1) = C(11, 3) = **165 solutions**

---

### Comparison Table: Different Selection Types

| Type | Order Matters? | Repetition Allowed? | Formula | Example |
|------|---------------|-------------------|---------|---------|
| Permutation | Yes | No | n!/(n-r)! | Race winners |
| Combination | No | No | n!/[r!(n-r)!] | Committee selection |
| Permutation with Rep. | Yes | Yes | nʳ | Lock codes |
| Combination with Rep. | No | Yes | C(n+r-1, r) | Fruit selection |

---

### Practice Questions - Combinations

**Q1**: A bag contains 5 black and 6 red balls. In how many ways can 2 black and 3 red balls be selected?
<details>
<summary>Answer</summary>
⁵C₂ × ⁶C₃ = 10 × 20 = 200 ways
</details>

**Q2**: In how many ways can 3 books be selected from 10 different books if a particular book is always selected?
<details>
<summary>Answer</summary>
Fix 1 book, select 2 more from 9: ⁹C₂ = 36 ways
</details>

**Q3**: How many different sums of money can be formed from 1 one-rupee coin, 1 five-rupee coin, 1 ten-rupee coin, and 1 twenty-rupee coin?
<details>
<summary>Answer</summary>
Each coin can be selected or not: 2⁴ = 16 ways
Subtract case of selecting no coins: 16 - 1 = 15 different sums
</details>

---

### Quick Review Summary - Combinations
- **ⁿCᵣ = n!/[r!(n-r)!]**: Select r from n objects
- **ⁿCᵣ = ⁿCₙ₋ᵣ**: Symmetry property
- **With repetition**: C(n+r-1, r)
- **At least one**: Total - None
- **Distribution**: Use stars and bars method

---

## UNIT 1.4: BINOMIAL THEOREM

### 1.4.1 Introduction to Binomial Theorem

**Definition**: The **Binomial Theorem** describes the algebraic expansion of powers of a binomial expression (x + y)ⁿ.

**Binomial Theorem Statement**:
For any positive integer *n* and any real numbers *x* and *y*:
```
(x + y)ⁿ = ⁿC₀·xⁿ·y⁰ + ⁿC₁·xⁿ⁻¹·y¹ + ⁿC₂·xⁿ⁻²·y² + ... + ⁿCₙ·x⁰·yⁿ
```

**Sigma Notation**:
```
(x + y)ⁿ = Σ(r=0 to n) ⁿCᵣ · xⁿ⁻ʳ · yʳ
```

---

### 1.4.2 General Term and Binomial Coefficients

**General Term (r+1)th term**:
```
Tᵣ₊₁ = ⁿCᵣ · xⁿ⁻ʳ · yʳ
```

**Binomial Coefficients**:
The coefficients ⁿC₀, ⁿC₁, ⁿC₂, ..., ⁿCₙ are called **binomial coefficients**.

**Properties of Binomial Coefficients**:
1. Symmetric: ⁿCᵣ = ⁿCₙ₋ᵣ
2. Maximum value occurs at middle term(s)
3. Sum of all coefficients: Put x = y = 1 → (1+1)ⁿ = 2ⁿ

---

### 1.4.3 Important Special Cases

**Case 1**: (x + y)ⁿ - Standard form

**Case 2**: (x - y)ⁿ
```
(x - y)ⁿ = ⁿC₀·xⁿ - ⁿC₁·xⁿ⁻¹·y + ⁿC₂·xⁿ⁻²·y² - ... + (-1)ⁿ·ⁿCₙ·yⁿ
```

**Case 3**: (1 + x)ⁿ
```
(1 + x)ⁿ = ⁿC₀ + ⁿC₁·x + ⁿC₂·x² + ... + ⁿCₙ·xⁿ
```

**Case 4**: (1 - x)ⁿ
```
(1 - x)ⁿ = ⁿC₀ - ⁿC₁·x + ⁿC₂·x² - ... + (-1)ⁿ·ⁿCₙ·xⁿ
```

---

### 1.4.4 Finding Specific Terms

**Example 1**: Find the 6th term in the expansion of (2x - 3y)¹².
- **Solution**:
  - 6th term = T₆ = T₅₊₁
  - T₅₊₁ = ¹²C₅ · (2x)¹²⁻⁵ · (-3y)⁵
  - = ¹²C₅ · (2x)⁷ · (-3y)⁵
  - = 792 · 128x⁷ · (-243y⁵)
  - = **-24,649,728 x⁷y⁵**

**Example 2**: Find the middle term in the expansion of (x + y)⁸.
- **Solution**:
  - n = 8 (even)
  - Middle term = (8/2 + 1)th term = 5th term = T₄₊₁
  - T₅ = ⁸C₄ · x⁴ · y⁴
  - = **70x⁴y⁴**

**Example 3**: In the expansion of (2x - 3y)⁹, find the coefficient of x⁶y³.
- **Solution**:
  - General term: Tᵣ₊₁ = ⁹Cᵣ · (2x)⁹⁻ʳ · (-3y)ʳ
  - For x⁶y³: 9-r = 6 → r = 3
  - T₄ = ⁹C₃ · (2x)⁶ · (-3y)³
  - = 84 · 64x⁶ · (-27y³)
  - Coefficient = **-145,152**

---

### 1.4.5 Applications of Binomial Theorem

**Application 1: Finding Remainders**

**Example**: Find the remainder when 82 is divided by 9.
- **Solution**:
  - 82 = (9-1)² = ⁹C₀·9² - ⁹C₁·9 + ⁹C₂
  - ≡ ⁹C₂ (mod 9)
  - = 1 (mod 9)
  - **Remainder = 1**

---

**Application 2: Approximations**

**Example**: Approximate (1.02)⁵ using binomial theorem.
- **Solution**:
  - (1.02)⁵ = (1 + 0.02)⁵
  - ≈ ⁵C₀ + ⁵C₁(0.02) + ⁵C₂(0.02)²
  - = 1 + 5(0.02) + 10(0.0004)
  - = 1 + 0.1 + 0.004
  - ≈ **1.104**

---

### 1.4.6 Important Identities

**Identity 1**: Sum of binomial coefficients
```
ⁿC₀ + ⁿC₁ + ⁿC₂ + ... + ⁿCₙ = 2ⁿ
```
*Proof*: Put x = y = 1 in (x+y)ⁿ

**Identity 2**: Alternating sum
```
ⁿC₀ - ⁿC₁ + ⁿC₂ - ⁿC₃ + ... + (-1)ⁿ·ⁿCₙ = 0
```
*Proof*: Put x = 1, y = -1 in (x+y)ⁿ

**Identity 3**: Sum of odd-positioned coefficients = Sum of even-positioned coefficients
```
ⁿC₀ + ⁿC₂ + ⁿC₄ + ... = ⁿC₁ + ⁿC₃ + ⁿC₅ + ... = 2ⁿ⁻¹
```

---

### Practice Questions - Binomial Theorem

**Q1**: Find the coefficient of x⁷ in (2x² + 1/x)¹⁵.
<details>
<summary>Answer</summary>
General term: Tᵣ₊₁ = ¹⁵Cᵣ · (2x²)¹⁵⁻ʳ · (1/x)ʳ = ¹⁵Cᵣ · 2¹⁵⁻ʳ · x³⁰⁻³ʳ
For x⁷: 30-3r = 7 → r = 23/3 (not integer)
No term with x⁷ exists, coefficient = 0
</details>

**Q2**: Prove that ⁿC₀ + 2·ⁿC₁ + 4·ⁿC₂ + ... + 2ⁿ·ⁿCₙ = 3ⁿ
<details>
<summary>Answer</summary>
Put x = 2, y = 1 in (x+y)ⁿ
(2+1)ⁿ = ⁿC₀·2⁰ + ⁿC₁·2¹ + ⁿC₂·2² + ... + ⁿCₙ·2ⁿ
3ⁿ = ⁿC₀ + 2·ⁿC₁ + 4·ⁿC₂ + ... + 2ⁿ·ⁿCₙ ✓
</details>

---

## UNIT 1.5: CATALAN NUMBERS

### 1.5.1 Introduction to Catalan Numbers

**Definition**: The **Catalan numbers** form a sequence of natural numbers that occur in various counting problems. The nth Catalan number is denoted by **Cₙ** or **bₙ**.

**First few Catalan numbers**:
```
C₀ = 1
C₁ = 1
C₂ = 2
C₃ = 5
C₄ = 14
C₅ = 42
C₆ = 132
```

---

### 1.5.2 Formulas for Catalan Numbers

**Formula 1**: Using binomial coefficients
```
Cₙ = (1/(n+1)) · ²ⁿCₙ = ²ⁿCₙ / (n+1)
```

**Formula 2**: Using factorials
```
Cₙ = (2n)! / [(n+1)! · n!]
```

**Formula 3**: Difference form
```
Cₙ = ²ⁿCₙ - ²ⁿCₙ₊₁
```

**Recursive Formula**:
```
C₀ = 1
Cₙ = C₀·Cₙ₋₁ + C₁·Cₙ₋₂ + C₂·Cₙ₋₃ + ... + Cₙ₋₁·C₀
```

---

### 1.5.3 Derivation of Catalan Formula

**Proof** that Cₙ = ²ⁿCₙ - ²ⁿCₙ₊₁:

Starting with:
```
Cₙ = ²ⁿCₙ / (n+1)
```

We can write:
```
Cₙ(n+1) = ²ⁿCₙ
```

Now:
```
²ⁿCₙ - ²ⁿCₙ₊₁ = [2n)! / (n! · n!)] - [(2n)! / ((n+1)! · (n-1)!)]
                 = (2n)! · [1/(n! · n!) - 1/((n+1)! · (n-1)!)]
                 = (2n)! · [(n+1 - n) / ((n+1)! · n!)]
                 = (2n)! / [(n+1)! · n!]
                 = (1/(n+1)) · ²ⁿCₙ
                 = Cₙ
```

---

### 1.5.4 Applications of Catalan Numbers

**Application 1**: **Valid Parentheses Sequences**
The number of valid sequences of n pairs of parentheses = Cₙ

**Example**: For n=3, the valid sequences are:
```
()()(), ()(()), (())(), (()()), ((()))
Count = C₃ = 5 ✓
```

---

**Application 2**: **Binary Trees**
The number of full binary trees with n+1 leaves (or n internal nodes) = Cₙ

---

**Application 3**: **Polygon Triangulation**
The number of ways to triangulate a convex polygon with n+2 sides = Cₙ

---

**Application 4**: **Ballot Problem**
In an election where candidate A receives n votes and candidate B receives n votes, the number of ways the votes can be ordered such that A is always ahead or tied = Cₙ

---

**Application 5**: **Monotonic Lattice Paths**
The number of paths from (0,0) to (n,n) that don't cross the diagonal y=x using only right (R) and up (U) moves = Cₙ

---

### 1.5.5 Computing Catalan Numbers

**Example 1**: Calculate C₄ using the binomial formula.
- **Solution**:
  - C₄ = ⁸C₄ / (4+1)
  - = [8!/(4!·4!)] / 5
  - = 70 / 5
  - = **14**

**Example 2**: Calculate C₅ using the difference formula.
- **Solution**:
  - C₅ = ¹⁰C₅ - ¹⁰C₆
  - = 252 - 210
  - = **42**

**Example 3**: How many ways can we arrange valid parentheses with 4 pairs?
- **Solution**: C₄ = **14 ways**

---

### Practice Questions - Catalan Numbers

**Q1**: Calculate C₆ using any formula.
<details>
<summary>Answer</summary>
C₆ = ¹²C₆ / 7 = 924 / 7 = 132
</details>

**Q2**: How many full binary trees can be formed with 7 leaves?
<details>
<summary>Answer</summary>
n+1 = 7 → n = 6
Number of trees = C₆ = 132
</details>

---

## UNIT 1.6: ADVANCED PROBLEMS

### 1.6.1 Derangements

**Definition**: A **derangement** is a permutation where no element appears in its original position.

**Formula**: Number of derangements of n objects:
```
Dₙ = n! · [1 - 1/1! + 1/2! - 1/3! + ... + (-1)ⁿ/n!]
```

**Approximation**: Dₙ ≈ n!/e

---

### 1.6.2 Inclusion-Exclusion Principle

**Principle**: For sets A and B:
```
|A ∪ B| = |A| + |B| - |A ∩ B|
```

**For three sets**:
```
|A ∪ B ∪ C| = |A| + |B| + |C| - |A ∩ B| - |A ∩ C| - |B ∩ C| + |A ∩ B ∩ C|
```

---

### 1.6.3 Pigeonhole Principle

**Principle**: If n+1 or more objects are placed into n boxes, then at least one box contains two or more objects.

**Example**: In any group of 13 people, at least 2 must have birthdays in the same month.

---

## MODULE 1 SUMMARY

### Top 10 Most Testable Facts

1. **Multiplication vs Addition Principle**: Multiplication for sequential AND tasks, Addition for mutually exclusive OR choices
2. **ⁿPᵣ = n!/(n-r)!**: Permutation formula - order matters
3. **ⁿCᵣ = n!/[r!(n-r)!]**: Combination formula - order doesn't matter
4. **Permutations with repetition**: nʳ objects, repetition allowed
5. **Identical objects**: n!/(p₁!×p₂!×...×pₖ!) for grouping identical items
6. **Combinations with repetition**: C(n+r-1, r) - stars and bars method
7. **Circular permutations**: (n-1)! for arranging n objects in a circle
8. **Binomial expansion**: (x+y)ⁿ = Σ ⁿCᵣ·xⁿ⁻ʳ·yʳ
9. **Catalan numbers**: Cₙ = ²ⁿCₙ/(n+1) - used for bracket matching, binary trees
10. **Key property**: ⁿCᵣ = ⁿCₙ₋ᵣ (symmetry in combinations)

---

### Common Question Patterns

| Pattern | Approach | Example |
|---------|----------|---------|
| "Arrange n objects" | Use nPn or n! | Arrange 5 books |
| "Select r from n" | Use ⁿCᵣ | Committee of 5 from 12 |
| "At least/at most" | Use complementary counting | At least 1 woman |
| "With repetition" | Use nʳ or C(n+r-1,r) | Lock codes, fruit selection |
| "Together/Apart" | Unit method or subtraction | Couples sitting together |

---

### MODULE 1 - QUICK REFERENCE CHEAT SHEET

| Concept | Formula | When to Use |
|---------|---------|-------------|
| **Multiplication Principle** | m × n | Sequential tasks (AND) |
| **Addition Principle** | m + n | Mutually exclusive (OR) |
| **Permutations (all)** | n! | Arrange all n objects |
| **Permutations (r from n)** | n!/(n-r)! | Arrange r from n objects |
| **Permutations (repetition)** | nʳ | Arrangements with repetition |
| **Permutations (identical)** | n!/(p₁!×p₂!×...×pₖ!) | Objects with duplicates |
| **Circular Permutations** | (n-1)! | Arrangements in circle |
| **Combinations** | n!/[r!(n-r)!] | Selections (order doesn't matter) |
| **Combinations (repetition)** | C(n+r-1, r) | Selections with repetition |
| **Binomial Theorem** | (x+y)ⁿ = Σ ⁿCᵣ·xⁿ⁻ʳ·yʳ | Algebraic expansions |
| **Catalan Numbers** | Cₙ = ²ⁿCₙ/(n+1) | Bracket matching, trees |

---

### Mini Quiz - Module 1

**Question 1**: In how many ways can 6 people be arranged in a row?
<details>
<summary>Answer</summary>
6! = 720 ways
</details>

**Question 2**: How many committees of 4 can be formed from 10 people?
<details>
<summary>Answer</summary>
¹⁰C₄ = 210 committees
</details>

**Question 3**: How many 4-digit numbers can be formed using digits 1-5 with repetition?
<details>
<summary>Answer</summary>
5⁴ = 625 numbers
</details>

**Question 4**: In how many ways can the letters of "MISSISSIPPI" be arranged?
<details>
<summary>Answer</summary>
11!/(1!×4!×4!×2!) = 34,650 ways
</details>

**Question 5**: How many ways to select 5 balls from 3 colors with unlimited balls of each color?
<details>
<summary>Answer</summary>
C(3+5-1, 5) = C(7,5) = 21 ways
</details>

**Question 6**: What is the coefficient of x⁵ in (2+x)⁸?
<details>
<summary>Answer</summary>
⁸C₅ × 2³ × 1⁵ = 56 × 8 = 448
</details>

**Question 7**: Find C₃ (3rd Catalan number).
<details>
<summary>Answer</summary>
C₃ = ⁶C₃/4 = 20/4 = 5
</details>

**Question 8**: A basketball team has 5 centers and 8 guards. In how many ways can a starting lineup of 1 center and 2 guards be chosen?
<details>
<summary>Answer</summary>
⁵C₁ × ⁸C₂ = 5 × 28 = 140 ways
</details>

**Question 9**: How many 5-letter words can be formed using A,B,C if each letter must appear at least once?
<details>
<summary>Answer</summary>
Total - (missing one or more)
3⁵ - [3×2⁵ - 3×1⁵] = 243 - 93 = 150 words
</details>

**Question 10**: In how many ways can 8 people be seated around a circular table if 2 specific people must sit together?
<details>
<summary>Answer</summary>
Treat 2 as unit: 6! = 720
Within unit: 2! = 2
Total = 720 × 2 = 1,440 ways
</details>

---

# MODULE 2: SETS

## Learning Objectives
- Understand set definitions and notations
- Master set operations and their properties
- Apply Venn diagrams for problem-solving
- Learn laws and identities of set theory
- Solve problems involving cardinality and power sets

---

## UNIT 2.1: INTRODUCTION TO SETS

### 2.1.1 Definition and Basic Concepts

**Definition**: A **set** is a well-defined collection of distinct objects. Each object in a set is called an **element** or **member** of the set.

**Key Characteristics**:
- **Well-defined**: Clear criteria for membership
- **Distinct**: No repetition of elements
- **Unordered**: {1,2,3} = {3,1,2}

**Notation**:
- Sets: Denoted by capital letters (A, B, C, ...)
- Elements: Denoted by lowercase letters (a, b, c, ...)
- **∈**: "belongs to" or "is an element of"
- **∉**: "does not belong to" or "is not an element of"

**Examples**:
- A = {2, 4, 6, 8} - Set of first four even numbers
- B = {1, 3, 5, 7, 9, ...} - Set of odd natural numbers
- C = {January, February, March, ..., December} - Set of months
- D = {a, e, i, o, u} - Set of vowels

---

### 2.1.2 Standard Sets

| Set | Notation | Description |
|-----|----------|-------------|
| **Natural Numbers** | ℕ or N | {1, 2, 3, 4, ...} |
| **Whole Numbers** | W | {0, 1, 2, 3, ...} |
| **Integers** | ℤ or Z | {..., -3, -2, -1, 0, 1, 2, 3, ...} |
| **Rational Numbers** | ℚ or Q | {p/q : p,q ∈ ℤ, q ≠ 0} |
| **Irrational Numbers** | Q' | Numbers that cannot be expressed as p/q |
| **Real Numbers** | ℝ or R | Q ∪ Q' (all rational and irrational numbers) |
| **Complex Numbers** | ℂ or C | {a + ib : a,b ∈ ℝ, i = √(-1)} |

---

### 2.1.3 Elements and Membership

**Examples**:
- Let A = {5, 10, 15, 20, 25, ...} (multiples of 5)
- 30 ∈ A (30 belongs to A)
- 24 ∉ A (24 does not belong to A)

**Membership Testing**: To determine if x ∈ A, check if x satisfies the defining property of A.

---

### 2.1.4 Cardinality of a Set

**Definition**: The **cardinality** of a set is the number of elements in the set. For set A, cardinality is denoted by **|A|** or **n(A)**.

**Examples**:
- A = {5, 7, 9, 11, 13} → |A| = 5
- B = {a, e, i, o, u} → |B| = 5
- Empty set: |∅| = 0

**Properties**:
- Cardinality is always a non-negative integer
- For finite sets: |A| ∈ {0, 1, 2, 3, ...}
- For infinite sets: |A| = ∞

---

## UNIT 2.2: REPRESENTATION OF SETS

### 2.2.1 Roster Form (Tabular Form)

**Definition**: In roster form, all elements are listed explicitly, separated by commas, and enclosed in curly braces {}.

**Syntax**: A = {element₁, element₂, element₃, ...}

**Examples**:
- A = {2, 4, 8, 16, 32, ...} - Set of positive powers of 2
- B = {a, e, i, o, u} - Set of vowels
- C = {-3, -2, -1, 0, 1, 2, 3} - Set of integers from -3 to 3

**Advantages**: 
- Clear and explicit
- Easy to understand for small sets

**Limitations**:
- Impractical for large or infinite sets
- Requires pattern recognition with "..."

---

### 2.2.2 Set-Builder Form (Rule Method)

**Definition**: In set-builder form, we describe a set using a rule or property that its elements satisfy.

**Syntax**: A = {x : (condition on x)} or A = {x | (condition on x)}

Read as: "A is the set of all x such that (condition)"

**Examples**:
- A = {x : x is a prime number between 2 and 10}
  - Roster form: A = {2, 3, 5, 7}

- B = {x : x² = 9, x ∈ ℤ}
  - Roster form: B = {-3, 3}

- C = {x : x is a multiple of 3}
  - Roster form: C = {3, 6, 9, 12, ...}

- D = {x : 2 < x < 10, x ∈ ℕ}
  - Roster form: D = {3, 4, 5, 6, 7, 8, 9}

**Advantages**:
- Compact representation
- Works well for infinite sets
- Precisely defines membership criteria

---

### 2.2.3 Interval Notation

**For Real Numbers**: Used to represent continuous ranges

**Types of Intervals**:

| Notation | Set-Builder Form | Name | Diagram |
|----------|-----------------|------|---------|
| **(a, b)** | {x : a < x < b} | Open interval | ○―――○ |
| **[a, b]** | {x : a ≤ x ≤ b} | Closed interval | ●―――● |
| **[a, b)** | {x : a ≤ x < b} | Half-open (right) | ●―――○ |
| **(a, b]** | {x : a < x ≤ b} | Half-open (left) | ○―――● |

**Examples**:
- A = {x : 2 < x < 3, x ∈ ℝ} = (2, 3)
- B = {x : 0 ≤ x ≤ 1, x ∈ ℝ} = [0, 1]
- C = {x : -5 < x ≤ 10, x ∈ ℝ} = (-5, 10]
- D = {x : 5 ≤ x < 10, x ∈ ℝ} = [5, 10)

---

## UNIT 2.3: TYPES OF SETS

### 2.3.1 Empty Set (Null Set)

**Definition**: A set with **no elements** is called an empty set or null set.

**Notation**: ∅ or {}

**Examples**:
- A = {x : x ∈ ℕ, x < 1} = ∅
- B = {Set of months having 32 days} = ∅
- C = {x : x² = -4, x ∈ ℝ} = ∅

**Properties**:
- |∅| = 0
- ∅ is unique
- ∅ is a subset of every set

---

### 2.3.2 Singleton Set (Unit Set)

**Definition**: A set containing exactly **one element** is called a singleton set.

**Examples**:
- A = {Set of even prime numbers} = {2}
- B = {0}
- C = {x : x + 5 = 8, x ∈ ℕ} = {3}

**Properties**:
- |Singleton set| = 1
- Different from empty set

---

### 2.3.3 Finite and Infinite Sets

**Finite Set**: A set with a countable number of elements.

**Examples**:
- A = {1, 2, 3, 4, 5}
- B = {x : x is a month of the year}
- |A| = 5, |B| = 12

**Infinite Set**: A set with uncountably many elements.

**Examples**:
- ℕ = {1, 2, 3, 4, ...}
- ℤ = {..., -2, -1, 0, 1, 2, ...}
- ℝ = Set of all real numbers

**Properties**:
- Finite set: |A| = n (specific number)
- Infinite set: |A| = ∞

---

### 2.3.4 Equal Sets

**Definition**: Two sets A and B are **equal** if they contain exactly the same elements.

**Notation**: A = B

**Formal Definition**: A = B if and only if (x ∈ A ⟺ x ∈ B)

**Examples**:
- A = {1, 2, 3}, B = {3, 1, 2} → A = B
- C = {a, b, c}, D = {c, b, a} → C = D
- E = {x : x² = 4}, F = {-2, 2} → E = F

**Properties**:
- Order doesn't matter
- Repetition doesn't matter: {1,2,2,3} = {1,2,3}

---

### 2.3.5 Equivalent Sets

**Definition**: Two sets A and B are **equivalent** if they have the same number of elements.

**Notation**: A ~ B

**Formal Definition**: A ~ B if |A| = |B|

**Examples**:
- A = {1, 2, 3}, B = {a, b, c} → A ~ B (both have 3 elements)
- C = {5, 10}, D = {x, y} → C ~ D
- Equal sets are always equivalent, but equivalent sets need not be equal

**Comparison**:
| Equal Sets | Equivalent Sets |
|-----------|----------------|
| Same elements | Same cardinality |
| A = B ⇒ A ~ B | A ~ B ⇏ A = B |
| {1,2,3} = {3,1,2} | {1,2,3} ~ {a,b,c} |

---

### 2.3.6 Subsets and Supersets

**Subset Definition**: Set A is a **subset** of set B if every element of A is also an element of B.

**Notation**: A ⊆ B

**Formal Definition**: A ⊆ B if (x ∈ A ⇒ x ∈ B)

**Examples**:
- A = {1, 2}, B = {1, 2, 3, 4} → A ⊆ B
- ℕ ⊆ ℤ ⊆ ℚ ⊆ ℝ ⊆ ℂ
- ∅ ⊆ A for any set A

---

**Superset Definition**: If A ⊆ B, then B is a **superset** of A.

**Notation**: B ⊇ A

---

**Proper Subset**: Set A is a **proper subset** of B if A ⊆ B and A ≠ B.

**Notation**: A ⊂ B (or A ⊊ B)

**Examples**:
- {1, 2} ⊂ {1, 2, 3}
- {a} ⊂ {a, b, c}

**Properties**:
- Every set is a subset of itself: A ⊆ A
- Empty set is a subset of every set: ∅ ⊆ A
- If A ⊆ B and B ⊆ A, then A = B

**Number of Subsets**: A set with n elements has **2ⁿ subsets** (including ∅ and the set itself).

---

### 2.3.7 Universal Set

**Definition**: A **universal set** is a set that contains all elements under consideration for a particular discussion.

**Notation**: U or 𝒰

**Examples**:
- When discussing integers, U = ℤ
- When discussing students in a class, U = {all students in class}
- If A = {a, b}, B = {c, d}, C = {e, f}, then U = {a, b, c, d, e, f}

**Properties**:
- Every set is a subset of the universal set
- Universal set is context-dependent
- A ⊆ U for all sets A in the context

---

### 2.3.8 Power Set

**Definition**: The **power set** of a set A is the set of all subsets of A (including ∅ and A itself).

**Notation**: P(A) or 2^A

**Formal Definition**: P(A) = {X : X ⊆ A}

**Cardinality**: If |A| = n, then |P(A)| = 2ⁿ

**Examples**:

**Example 1**: A = {1, 2}
- P(A) = {∅, {1}, {2}, {1, 2}}
- |A| = 2, |P(A)| = 2² = 4 ✓

**Example 2**: A = {a, b, c}
- P(A) = {∅, {a}, {b}, {c}, {a,b}, {a,c}, {b,c}, {a,b,c}}
- |A| = 3, |P(A)| = 2³ = 8 ✓

**Example 3**: A = ∅
- P(∅) = {∅}
- |∅| = 0, |P(∅)| = 2⁰ = 1 ✓

**Properties**:
- ∅ ∈ P(A) for all sets A
- A ∈ P(A)
- If A ⊆ B, then P(A) ⊆ P(B)

---

## UNIT 2.4: VENN DIAGRAMS

### 2.4.1 Introduction to Venn Diagrams

**Definition**: A **Venn diagram** is a visual representation of sets using circles (or other closed curves) where:
- Universal set U is represented by a rectangle
- Sets are represented by circles inside the rectangle
- Elements are represented by points inside the circles

**Purpose**:
- Visualize relationships between sets
- Understand set operations
- Solve problems involving sets

---

### 2.4.2 Basic Venn Diagram Representations

**Single Set**:
```
┌─────────────────┐
│   U             │
│   ┌─────────┐   │
│   │    A    │   │
│   │         │   │
│   └─────────┘   │
│                 │
└─────────────────┘
```

**Two Sets - Overlapping**:
```
┌─────────────────┐
│   U             │
│  ┌────┐  ┌────┐ │
│  │ A  │∩│  B │ │
│  │    ││    │ │
│  └────┘  └────┘ │
│                 │
└─────────────────┘
```

**Two Sets - Disjoint**:
```
┌─────────────────┐
│   U             │
│  ┌────┐  ┌────┐ │
│  │ A  │  │  B │ │
│  └────┘  └────┘ │
│                 │
└─────────────────┘
```

**Three Sets**:
```
┌──────────────────┐
│   U              │
│    ┌───┐         │
│  ┌─┴─┬─┴─┐       │
│  │ A │ B │       │
│  └─┬─┴─┬─┘       │
│    │ C │         │
│    └───┘         │
│                  │
└──────────────────┘
```

---

## UNIT 2.5: SET OPERATIONS

### 2.5.1 Union of Sets

**Definition**: The **union** of sets A and B is the set of all elements that are in A **or** in B (or in both).

**Notation**: A ∪ B

**Formal Definition**: A ∪ B = {x : x ∈ A or x ∈ B}

**Venn Diagram**: The shaded region represents A ∪ B
```
┌─────────────────┐
│   U             │
│  ┌────┐  ┌────┐ │
│  │████│██│████│ │
│  │████││████│ │
│  └────┘  └────┘ │
└─────────────────┘
```

**Examples**:
- A = {1, 2, 3}, B = {3, 4, 5} → A ∪ B = {1, 2, 3, 4, 5}
- A = {a, b}, B = {c, d} → A ∪ B = {a, b, c, d}
- A = {x : x is even}, B = {x : x is odd} → A ∪ B = ℤ

**Properties**:
1. **Commutative**: A ∪ B = B ∪ A
2. **Associative**: (A ∪ B) ∪ C = A ∪ (B ∪ C)
3. **Identity**: A ∪ ∅ = A
4. **Idempotent**: A ∪ A = A
5. **Domination**: A ∪ U = U

---

### 2.5.2 Intersection of Sets

**Definition**: The **intersection** of sets A and B is the set of all elements that are in **both** A **and** B.

**Notation**: A ∩ B

**Formal Definition**: A ∩ B = {x : x ∈ A and x ∈ B}

**Venn Diagram**: The shaded region represents A ∩ B
```
┌─────────────────┐
│   U             │
│  ┌────┐  ┌────┐ │
│  │ A  │██│  B │ │
│  │    ││    │ │
│  └────┘  └────┘ │
└─────────────────┘
```

**Examples**:
- A = {1, 2, 3, 4}, B = {3, 4, 5, 6} → A ∩ B = {3, 4}
- A = {a, b, c}, B = {c, d, e} → A ∩ B = {c}
- A = {1, 2}, B = {3, 4} → A ∩ B = ∅ (disjoint sets)

**Properties**:
1. **Commutative**: A ∩ B = B ∩ A
2. **Associative**: (A ∩ B) ∩ C = A ∩ (B ∩ C)
3. **Identity**: A ∩ U = A
4. **Idempotent**: A ∩ A = A
5. **Domination**: A ∩ ∅ = ∅

**Disjoint Sets**: Sets A and B are disjoint if A ∩ B = ∅

---

### 2.5.3 Complement of a Set

**Definition**: The **complement** of set A is the set of all elements in the universal set U that are **not** in A.

**Notation**: A' or A^c or Ā

**Formal Definition**: A' = U - A = {x : x ∈ U and x ∉ A}

**Venn Diagram**: The shaded region represents A'
```
┌─────────────────┐
│████U████████████│
│██┌────┐█████████│
│██│ A  │█████████│
│██└────┘█████████│
│█████████████████│
└─────────────────┘
```

**Examples**:
- U = {1, 2, 3, 4, 5, 6}, A = {2, 4} → A' = {1, 3, 5, 6}
- U = ℝ, A = ℚ → A' = ℚ' (irrationals)
- U = {a, b, c, d}, A = {a, c} → A' = {b, d}

**Properties**:
1. **(A')' = A** (Double complement)
2. **A ∪ A' = U** (Law of union)
3. **A ∩ A' = ∅** (Law of intersection)
4. **U' = ∅** and **∅' = U**
5. **A ⊆ B ⇒ B' ⊆ A'**

---

### 2.5.4 Difference of Sets

**Definition**: The **difference** A - B (or A \ B) is the set of elements that are in A but **not** in B.

**Notation**: A - B or A \ B

**Formal Definition**: A - B = {x : x ∈ A and x ∉ B}

**Venn Diagram**: The shaded region represents A - B
```
┌─────────────────┐
│   U             │
│  ┌────┐  ┌────┐ │
│  │████│  │  B │ │
│  │████│  │    │ │
│  └────┘  └────┘ │
└─────────────────┘
```

**Examples**:
- A = {1, 2, 3, 4}, B = {3, 4, 5, 6} → A - B = {1, 2}
- A = {1, 2, 3, 4}, B = {3, 4, 5, 6} → B - A = {5, 6}
- A = {a, b, c}, B = {d, e} → A - B = {a, b, c}

**Properties**:
1. **A - B ≠ B - A** (Not commutative)
2. **A - B = A ∩ B'**
3. **A - ∅ = A**
4. **∅ - A = ∅**
5. **A - A = ∅**
6. **A - B = ∅ if A ⊆ B**

---

### 2.5.5 Symmetric Difference

**Definition**: The **symmetric difference** of A and B is the set of elements that are in A or B, but **not in both**.

**Notation**: A △ B or A ⊕ B

**Formal Definition**: A △ B = (A - B) ∪ (B - A) = (A ∪ B) - (A ∩ B)

**Venn Diagram**: The shaded region represents A △ B
```
┌─────────────────┐
│   U             │
│  ┌────┐  ┌────┐ │
│  │████│  │████│ │
│  │████│  │████│ │
│  └────┘  └────┘ │
└─────────────────┘
```

**Examples**:
- A = {1, 2, 3, 4}, B = {3, 4, 5, 6} → A △ B = {1, 2, 5, 6}
- A = {a, b}, B = {b, c, d} → A △ B = {a, c, d}
- A = {1, 2, 3}, B = {4, 5} → A △ B = {1, 2, 3, 4, 5}

**Properties**:
1. **Commutative**: A △ B = B △ A
2. **Associative**: (A △ B) △ C = A △ (B △ C)
3. **Identity**: A △ ∅ = A
4. **Self-inverse**: A △ A = ∅

---

## UNIT 2.6: LAWS OF SET ALGEBRA

### 2.6.1 Fundamental Laws

**1. Idempotent Laws**:
- A ∪ A = A
- A ∩ A = A

**2. Identity Laws**:
- A ∪ ∅ = A (∅ is the identity for union)
- A ∩ U = A (U is the identity for intersection)

**3. Domination Laws**:
- A ∪ U = U
- A ∩ ∅ = ∅

**4. Complement Laws**:
- A ∪ A' = U
- A ∩ A' = ∅
- (A')' = A
- U' = ∅, ∅' = U

**5. Commutative Laws**:
- A ∪ B = B ∪ A
- A ∩ B = B ∩ A

**6. Associative Laws**:
- (A ∪ B) ∪ C = A ∪ (B ∪ C)
- (A ∩ B) ∩ C = A ∩ (B ∩ C)

**7. Distributive Laws**:
- A ∪ (B ∩ C) = (A ∪ B) ∩ (A ∪ C)
- A ∩ (B ∪ C) = (A ∩ B) ∪ (A ∩ C)

**8. De Morgan's Laws** (Very Important!):
- (A ∪ B)' = A' ∩ B'
- (A ∩ B)' = A' ∪ B'

**9. Absorption Laws**:
- A ∪ (A ∩ B) = A
- A ∩ (A ∪ B) = A

---

### 2.6.2 Proving Set Identities

**Method 1: Element Argument**
Show that every element of LHS belongs to RHS and vice versa.

**Method 2: Venn Diagrams**
Shade both sides and verify they're identical.

**Method 3: Using Known Laws**
Apply laws step-by-step to transform one side into the other.

**Example**: Prove A - (B ∪ C) = (A - B) ∩ (A - C)

**Proof**:
```
LHS: A - (B ∪ C)
    = A ∩ (B ∪ C)'          [Definition of difference]
    = A ∩ (B' ∩ C')         [De Morgan's Law]
    = (A ∩ B') ∩ (A ∩ C')   [Distributive Law]
    = (A - B) ∩ (A - C)     [Definition of difference]
    = RHS
```

---

### 2.6.3 Set Identities Quick Reference

| Law | Union Form | Intersection Form |
|-----|-----------|-------------------|
| Identity | A ∪ ∅ = A | A ∩ U = A |
| Domination | A ∪ U = U | A ∩ ∅ = ∅ |
| Idempotent | A ∪ A = A | A ∩ A = A |
| Complement | A ∪ A' = U | A ∩ A' = ∅ |
| Commutative | A ∪ B = B ∪ A | A ∩ B = B ∩ A |
| Associative | (A ∪ B) ∪ C = A ∪ (B ∪ C) | (A ∩ B) ∩ C = A ∩ (B ∩ C) |
| Distributive | A ∪ (B ∩ C) = (A ∪ B) ∩ (A ∪ C) | A ∩ (B ∪ C) = (A ∩ B) ∪ (A ∩ C) |
| De Morgan's | (A ∪ B)' = A' ∩ B' | (A ∩ B)' = A' ∪ B' |

---

## UNIT 2.7: CARDINALITY AND COUNTING

### 2.7.1 Basic Cardinality Formulas

**For Union**:
```
|A ∪ B| = |A| + |B| - |A ∩ B|
```

**For Three Sets**:
```
|A ∪ B ∪ C| = |A| + |B| + |C| - |A ∩ B| - |A ∩ C| - |B ∩ C| + |A ∩ B ∩ C|
```

**For Disjoint Sets** (A ∩ B = ∅):
```
|A ∪ B| = |A| + |B|
```

**Examples**:

**Example 1**: In a class of 50 students, 30 study Mathematics, 25 study Physics, and 10 study both. How many study at least one subject?
- **Solution**:
  - |M| = 30, |P| = 25, |M ∩ P| = 10
  - |M ∪ P| = 30 + 25 - 10 = **45 students**

**Example 2**: In a survey, 100 people were asked about three products A, B, C:
- 50 use A, 40 use B, 30 use C
- 20 use A and B, 15 use B and C, 10 use A and C
- 5 use all three
- How many use at least one product?

- **Solution**:
  - |A ∪ B ∪ C| = 50 + 40 + 30 - 20 - 15 - 10 + 5 = **80 people**

---

## MODULE 2 SUMMARY

### Top 10 Most Testable Facts - Sets

1. **Empty set**: ∅ is subset of every set; |∅| = 0
2. **Power set**: If |A| = n, then |P(A)| = 2ⁿ
3. **Union formula**: |A ∪ B| = |A| + |B| - |A ∩ B|
4. **Subset relationships**: ∅ ⊆ A ⊆ U for all sets A
5. **Complement laws**: A ∪ A' = U and A ∩ A' = ∅
6. **De Morgan's Laws**: (A ∪ B)' = A' ∩ B' and (A ∩ B)' = A' ∪ B'
7. **Distributive laws**: A ∩ (B ∪ C) = (A ∩ B) ∪ (A ∩ C)
8. **Set difference**: A - B = A ∩ B'
9. **Symmetric difference**: A △ B = (A - B) ∪ (B - A)
10. **Cardinality of union**: For 3 sets, apply inclusion-exclusion principle

---

### Common Question Patterns - Sets

| Pattern | Approach | Example |
|---------|----------|---------|
| "Prove set identity" | Use laws or element argument | Prove A - (B ∩ C) = (A - B) ∪ (A - C) |
| "Find |A ∪ B|" | Use inclusion-exclusion | Given |A|=50, |B|=30, |A∩B|=10 |
| "Draw Venn diagram" | Show overlapping regions | Draw A ∩ (B ∪ C) |
| "Find complement" | Find elements not in set | A' = U - A |
| "Power set" | List all subsets | P({1,2}) = {∅,{1},{2},{1,2}} |

---

### Mini Quiz - Module 2

**Question 1**: If A = {1,2,3}, find P(A) and |P(A)|.
<details>
<summary>Answer</summary>
P(A) = {∅, {1}, {2}, {3}, {1,2}, {1,3}, {2,3}, {1,2,3}}
|P(A)| = 2³ = 8
</details>

**Question 2**: If |A| = 20, |B| = 30, |A ∪ B| = 40, find |A ∩ B|.
<details>
<summary>Answer</summary>
|A ∪ B| = |A| + |B| - |A ∩ B|
40 = 20 + 30 - |A ∩ B|
|A ∩ B| = 10
</details>

**Question 3**: Prove (A ∩ B)' = A' ∪ B' using laws.
<details>
<summary>Answer</summary>
This is De Morgan's Law (one of the fundamental laws of set theory).
Proof by element argument:
x ∈ (A ∩ B)' ⟺ x ∉ (A ∩ B)
⟺ x ∉ A or x ∉ B
⟺ x ∈ A' or x ∈ B'
⟺ x ∈ A' ∪ B'
</details>

**Question 4**: If U = {1,2,3,4,5,6,7,8}, A = {1,3,5,7}, B = {2,3,4,5}, find A △ B.
<details>
<summary>Answer</summary>
A △ B = (A - B) ∪ (B - A)
A - B = {1, 7}
B - A = {2, 4}
A △ B = {1, 2, 4, 7}
</details>

**Question 5**: How many subsets does a set with 5 elements have?
<details>
<summary>Answer</summary>
2⁵ = 32 subsets
</details>

---

# MODULE 3: PROPOSITIONAL LOGIC

## Learning Objectives
- Understand propositions and logical connectives
- Master truth tables and logical equivalences
- Apply laws of logic to simplify expressions
- Understand implications, arguments, and proof techniques
- Learn to evaluate logical statements and their validity

---

## UNIT 3.1: INTRODUCTION TO LOGIC

### 3.1.1 What is Logic?

**Definition**: **Logic** is the systematic study of the principles of valid reasoning and correct inference. In computer science and mathematics, we study **formal logic** which uses symbols and rules.

**Purpose in Computer Science**:
- Design of digital circuits
- Database query languages (SQL)
- Artificial Intelligence and reasoning systems
- Program verification and correctness
- Algorithm design and analysis

---

### 3.1.2 Propositions

**Definition**: A **proposition** (or **statement**) is a declarative sentence that is either **true** or **false**, but not both.

**Key Characteristics**:
- Declarative (makes a statement)
- Has a definite truth value (T or F)
- Not ambiguous

**Truth Values**:
- **True** (T or 1)
- **False** (F or 0)

**Examples of Propositions**:
- "The sky is blue." (True)
- "2 + 2 = 5" (False)
- "Delhi is the capital of India." (True)
- "All prime numbers are odd." (False - 2 is even)

**Not Propositions** (no definite truth value):
- "What time is it?" (Question)
- "Close the door." (Command)
- "x + 2 = 5" (Depends on value of x - open sentence)
- "This statement is false." (Paradox)

---

### 3.1.3 Notation

Propositions are usually denoted by lowercase letters: p, q, r, s, ...

**Example**:
- p: "It is raining."
- q: "The ground is wet."
- r: "2 + 3 = 5"

---

## UNIT 3.2: LOGICAL CONNECTIVES

### 3.2.1 Negation (NOT)

**Definition**: The **negation** of proposition p is "not p", denoted by **¬p** or **~p** or **p'**.

**Truth Table**:
| p | ¬p |
|---|---|
| T | F |
| F | T |

**Examples**:
- p: "It is raining." → ¬p: "It is not raining."
- q: "5 > 3" (T) → ¬q: "5 ≤ 3" (F)

**Properties**:
- Double negation: ¬(¬p) = p
- Negation changes truth value

---

### 3.2.2 Conjunction (AND)

**Definition**: The **conjunction** of p and q is "p and q", denoted by **p ∧ q**.

**Truth**: p ∧ q is true only when **both p and q are true**.

**Truth Table**:
| p | q | p ∧ q |
|---|---|-------|
| T | T | T |
| T | F | F |
| F | T | F |
| F | F | F |

**Examples**:
- p: "It is raining." q: "It is cold."
- p ∧ q: "It is raining and it is cold."
- If p = T and q = F, then p ∧ q = F

---

### 3.2.3 Disjunction (OR)

**Definition**: The **disjunction** of p and q is "p or q", denoted by **p ∨ q**.

**Truth**: p ∨ q is true when **at least one of p or q is true** (inclusive OR).

**Truth Table**:
| p | q | p ∨ q |
|---|---|-------|
| T | T | T |
| T | F | T |
| F | T | T |
| F | F | F |

**Examples**:
- p: "I will study Math." q: "I will study Physics."
- p ∨ q: "I will study Math or Physics (or both)."

**Note**: In logic, OR is **inclusive** (allows both to be true), unlike everyday usage which is often exclusive.

---

### 3.2.4 Exclusive OR (XOR)

**Definition**: The **exclusive or** of p and q is denoted by **p ⊕ q**.

**Truth**: p ⊕ q is true when **exactly one** of p or q is true (but not both).

**Truth Table**:
| p | q | p ⊕ q |
|---|---|-------|
| T | T | F |
| T | F | T |
| F | T | T |
| F | F | F |

**Formula**: p ⊕ q = (p ∨ q) ∧ ¬(p ∧ q)

---

### 3.2.5 Conditional (Implication)

**Definition**: The **conditional** "if p then q" is denoted by **p → q** or **p ⇒ q**.

- p is called the **hypothesis** or **antecedent**
- q is called the **conclusion** or **consequent**

**Truth**: p → q is false **only** when p is true and q is false.

**Truth Table**:
| p | q | p → q |
|---|---|-------|
| T | T | T |
| T | F | F |
| F | T | T |
| F | F | T |

**Important**: "If p then q" is true whenever:
- p and q are both true
- p is false (regardless of q)

**Examples**:
- "If it rains, then the ground is wet." (Makes sense)
- "If 2+2=5, then I am the King." (Vacuously true - false hypothesis)

**Equivalent Forms** of p → q:
- p implies q
- p is sufficient for q
- q is necessary for p
- q whenever p
- q follows from p
- ¬p ∨ q (logical equivalence)

---

### 3.2.6 Biconditional (If and Only If)

**Definition**: The **biconditional** "p if and only if q" is denoted by **p ↔ q** or **p ⇔ q**.

**Truth**: p ↔ q is true when p and q have the **same truth value**.

**Truth Table**:
| p | q | p ↔ q |
|---|---|-------|
| T | T | T |
| T | F | F |
| F | T | F |
| F | F | T |

**Formula**: p ↔ q = (p → q) ∧ (q → p)

**Examples**:
- "x > 0 if and only if x is positive."
- "A triangle is equilateral iff all its sides are equal."

**Alternative Notation**: "iff" means "if and only if"

---

### Summary of Logical Connectives

| Connective | Symbol | Name | True When... |
|-----------|--------|------|--------------|
| NOT | ¬p | Negation | p is false |
| AND | p ∧ q | Conjunction | Both p and q are true |
| OR | p ∨ q | Disjunction | At least one is true |
| XOR | p ⊕ q | Exclusive Or | Exactly one is true |
| IF-THEN | p → q | Conditional | p is false or q is true |
| IFF | p ↔ q | Biconditional | Same truth values |

---

## UNIT 3.3: TRUTH TABLES

### 3.3.1 Constructing Truth Tables

**Steps**:
1. Identify all propositional variables
2. Create columns for each variable and subformula
3. Calculate rows: If n variables, create 2ⁿ rows
4. Fill in truth values systematically

**Example**: Construct truth table for (p ∧ q) → r

| p | q | r | p ∧ q | (p ∧ q) → r |
|---|---|---|-------|-------------|
| T | T | T | T | T |
| T | T | F | T | F |
| T | F | T | F | T |
| T | F | F | F | T |
| F | T | T | F | T |
| F | T | F | F | T |
| F | F | T | F | T |
| F | F | F | F | T |

---

## UNIT 3.4: LOGICAL EQUIVALENCES

### 3.4.1 Definition

**Definition**: Two propositions p and q are **logically equivalent** if they have identical truth values in all possible cases.

**Notation**: p ≡ q or p ⇔ q

**Verification**: Check if truth tables are identical.

---

### 3.4.2 Important Logical Equivalences

**Identity Laws**:
- p ∧ T ≡ p
- p ∨ F ≡ p

**Domination Laws**:
- p ∨ T ≡ T
- p ∧ F ≡ F

**Idempotent Laws**:
- p ∨ p ≡ p
- p ∧ p ≡ p

**Double Negation**:
- ¬(¬p) ≡ p

**Commutative Laws**:
- p ∨ q ≡ q ∨ p
- p ∧ q ≡ q ∧ p

**Associative Laws**:
- (p ∨ q) ∨ r ≡ p ∨ (q ∨ r)
- (p ∧ q) ∧ r ≡ p ∧ (q ∧ r)

**Distributive Laws**:
- p ∨ (q ∧ r) ≡ (p ∨ q) ∧ (p ∨ r)
- p ∧ (q ∨ r) ≡ (p ∧ q) ∨ (p ∧ r)

**De Morgan's Laws** (Very Important!):
- ¬(p ∧ q) ≡ ¬p ∨ ¬q
- ¬(p ∨ q) ≡ ¬p ∧ ¬q

**Absorption Laws**:
- p ∨ (p ∧ q) ≡ p
- p ∧ (p ∨ q) ≡ p

**Conditional Equivalences**:
- p → q ≡ ¬p ∨ q
- p → q ≡ ¬q → ¬p (Contrapositive)
- ¬(p → q) ≡ p ∧ ¬q

**Biconditional Equivalences**:
- p ↔ q ≡ (p → q) ∧ (q → p)
- p ↔ q ≡ (p ∧ q) ∨ (¬p ∧ ¬q)

---

## UNIT 3.5: TAUTOLOGIES, CONTRADICTIONS, AND CONTINGENCIES

### 3.5.1 Definitions

**Tautology**: A proposition that is **always true**, regardless of truth values of its components.
- Example: p ∨ ¬p (Law of Excluded Middle)
- Symbol: ⊤ (represents always true)

**Contradiction**: A proposition that is **always false**.
- Example: p ∧ ¬p
- Symbol: ⊥ (represents always false)

**Contingency**: A proposition that is **sometimes true and sometimes false**.
- Example: p ∨ q
- Most everyday statements are contingencies

---

### 3.5.2 Examples

**Example 1**: Show that (p → q) ↔ (¬p ∨ q) is a tautology.

| p | q | p → q | ¬p | ¬p ∨ q | (p → q) ↔ (¬p ∨ q) |
|---|---|-------|-------|--------|---------------------|
| T | T | T | F | T | T |
| T | F | F | F | F | T |
| F | T | T | T | T | T |
| F | F | T | T | T | T |

All entries in final column are T, so it's a **tautology** ✓

**Example 2**: Show that p ∧ ¬p is a contradiction.

| p | ¬p | p ∧ ¬p |
|---|-------|---------|
| T | F | F |
| F | T | F |

All entries are F, so it's a **contradiction** ✓

---

## UNIT 3.6: LOGICAL ARGUMENTS AND INFERENCE

### 3.6.1 Arguments

**Definition**: An **argument** consists of:
- **Premises**: Propositions assumed to be true (p₁, p₂, ..., pₙ)
- **Conclusion**: Proposition that follows from premises (q)

**Notation**: 
```
p₁
p₂
...
pₙ
∴ q  (therefore q)
```

**Valid Argument**: An argument is **valid** if whenever all premises are true, the conclusion must also be true.

---

### 3.6.2 Rules of Inference

**Modus Ponens** (Method of Affirming):
```
p → q
p
∴ q
```
Example: "If it rains, the ground is wet. It is raining. Therefore, the ground is wet."

**Modus Tollens** (Method of Denying):
```
p → q
¬q
∴ ¬p
```
Example: "If it rains, the ground is wet. The ground is not wet. Therefore, it is not raining."

**Hypothetical Syllogism**:
```
p → q
q → r
∴ p → r
```
Example: "If I study, I pass. If I pass, I graduate. Therefore, if I study, I graduate."

**Disjunctive Syllogism**:
```
p ∨ q
¬p
∴ q
```
Example: "It's either raining or sunny. It's not raining. Therefore, it's sunny."

**Addition**:
```
p
∴ p ∨ q
```

**Simplification**:
```
p ∧ q
∴ p
```

**Conjunction**:
```
p
q
∴ p ∧ q
```

**Resolution**:
```
p ∨ q
¬p ∨ r
∴ q ∨ r
```

---

## UNIT 3.7: QUANTIFIERS

### 3.7.1 Universal Quantifier

**Symbol**: ∀ (for all)

**Meaning**: ∀x P(x) means "P(x) is true for all values of x in the domain"

**Examples**:
- ∀x (x² ≥ 0) - "All squares are non-negative"
- ∀n ∈ ℕ (n + 1 > n) - "For all natural numbers, n+1 is greater than n"

---

### 3.7.2 Existential Quantifier

**Symbol**: ∃ (there exists)

**Meaning**: ∃x P(x) means "There exists at least one x such that P(x) is true"

**Examples**:
- ∃x (x² = 4) - "There exists a number whose square is 4"
- ∃n ∈ ℕ (n is prime and n is even) - "There exists an even prime number" (true: n=2)

---

### 3.7.3 Negation of Quantifiers

**Rules**:
- ¬(∀x P(x)) ≡ ∃x ¬P(x)
- ¬(∃x P(x)) ≡ ∀x ¬P(x)

**Examples**:
- ¬(∀x (x > 0)) ≡ ∃x (x ≤ 0) - "Not all x are positive" means "Some x is not positive"
- ¬(∃x (x² < 0)) ≡ ∀x (x² ≥ 0) - "No x has negative square" means "All squares are non-negative"

---

## MODULE 3 SUMMARY

### Top 10 Most Testable Facts - Logic

1. **Proposition**: Declarative statement that is either true or false
2. **Truth tables**: Use 2ⁿ rows for n variables
3. **De Morgan's Laws**: ¬(p ∧ q) ≡ ¬p ∨ ¬q and ¬(p ∨ q) ≡ ¬p ∧ ¬q
4. **Conditional**: p → q is false only when p is true and q is false
5. **Contrapositive**: p → q ≡ ¬q → ¬p (always equivalent)
6. **Tautology**: Always true (e.g., p ∨ ¬p)
7. **Contradiction**: Always false (e.g., p ∧ ¬p)
8. **Modus Ponens**: From p → q and p, conclude q
9. **Modus Tollens**: From p → q and ¬q, conclude ¬p
10. **Quantifier negation**: ¬∀x P(x) ≡ ∃x ¬P(x)

---

### Common Question Patterns - Logic

| Pattern | Approach | Example |
|---------|----------|---------|
| "Construct truth table" | List all variable combinations | Truth table for (p ∧ q) → r |
| "Prove logical equivalence" | Show same truth values | Prove p → q ≡ ¬p ∨ q |
| "Is it a tautology?" | Check if always true | Is p ∨ ¬p a tautology? |
| "Negate the statement" | Apply negation rules | Negate ∀x (x > 0) |
| "Valid argument?" | Check if conclusion follows | Given premises, is conclusion valid? |

---

### Mini Quiz - Module 3

**Question 1**: Construct truth table for ¬(p ∧ q).
<details>
<summary>Answer</summary>
| p | q | p ∧ q | ¬(p ∧ q) |
|---|---|-------|----------|
| T | T | T | F |
| T | F | F | T |
| F | T | F | T |
| F | F | F | T |
</details>

**Question 2**: Is (p → q) ∧ (¬q) → (¬p) a tautology?
<details>
<summary>Answer</summary>
Yes, this is Modus Tollens, which is always valid.
</details>

**Question 3**: Negate: ∀x ∃y (x + y = 0)
<details>
<summary>Answer</summary>
∃x ∀y (x + y ≠ 0)
"There exists an x such that for all y, x+y is not zero"
</details>

**Question 4**: What is the contrapositive of "If it rains, then the ground is wet"?
<details>
<summary>Answer</summary>
"If the ground is not wet, then it does not rain"
</details>

**Question 5**: Prove using truth table: p → q ≡ ¬p ∨ q
<details>
<summary>Answer</summary>
| p | q | p → q | ¬p | ¬p ∨ q |
|---|---|-------|-----|--------|
| T | T | T | F | T |
| T | F | F | F | F |
| F | T | T | T | T |
| F | F | T | T | T |

Columns for p → q and ¬p ∨ q are identical, so they're equivalent ✓
</details>

---

# COMPREHENSIVE FINAL REVIEW

## Master Formula Sheet

### Permutations & Combinations

| Formula | Description |
|---------|-------------|
| n! | n factorial = n × (n-1) × ... × 1 |
| ⁿPᵣ = n!/(n-r)! | Permutations: r from n |
| ⁿCᵣ = n!/[r!(n-r)!] | Combinations: r from n |
| nʳ | Permutations with repetition |
| n!/(p₁!×p₂!×...×pₖ!) | Permutations with identical objects |
| (n-1)! | Circular permutations |
| C(n+r-1, r) | Combinations with repetition |
| (x+y)ⁿ = Σ ⁿCᵣ·xⁿ⁻ʳ·yʳ | Binomial theorem |
| Cₙ = ²ⁿCₙ/(n+1) | nth Catalan number |
| ⁿC₀ + ⁿC₁ + ... + ⁿCₙ = 2ⁿ | Sum of binomial coefficients |

### Sets

| Formula | Description |
|---------|-------------|
| \|A ∪ B\| = \|A\| + \|B\| - \|A ∩ B\| | Cardinality of union |
| \|P(A)\| = 2ⁿ if \|A\| = n | Power set cardinality |
| A - B = A ∩ B' | Set difference |
| A △ B = (A-B) ∪ (B-A) | Symmetric difference |
| (A ∪ B)' = A' ∩ B' | De Morgan's Law |
| (A ∩ B)' = A' ∪ B' | De Morgan's Law |

### Logic

| Formula | Description |
|---------|-------------|
| p → q ≡ ¬p ∨ q | Conditional equivalence |
| p → q ≡ ¬q → ¬p | Contrapositive |
| ¬(p ∧ q) ≡ ¬p ∨ ¬q | De Morgan's Law |
| ¬(p ∨ q) ≡ ¬p ∧ ¬q | De Morgan's Law |
| ¬∀x P(x) ≡ ∃x ¬P(x) | Quantifier negation |
| ¬∃x P(x) ≡ ∀x ¬P(x) | Quantifier negation |

---

## Problem-Solving Strategies

### For Counting Problems
1. **Identify the type**: Arrangement (permutation) or selection (combination)?
2. **Check for repetition**: Can elements repeat?
3. **Check for restrictions**: Together/apart, specific positions?
4. **Apply appropriate formula**: Use the formula sheet
5. **Verify**: Does the answer make sense?

### For Set Problems
1. **Draw Venn diagram**: Visualize relationships
2. **Identify operation**: Union, intersection, complement?
3. **Apply formulas**: Use cardinality formulas
4. **Check laws**: Can you simplify using set laws?
5. **Verify**: Test with small examples

### For Logic Problems
1. **Identify connectives**: AND, OR, NOT, →, ↔?
2. **Build truth table**: List all cases systematically
3. **Apply laws**: Can you simplify the expression?
4. **Check for patterns**: Tautology, contradiction, or contingency?
5. **Verify**: Does the logic make sense?

---

## Mnemonics and Memory Aids

### Permutations vs Combinations
**"Arrangements PICK order, Selections DON'T"**
- **PICK** → Permutations
- **DON'T** → Combinations

### De Morgan's Laws
**"Break the bar, change the sign"**
- ¬(A ∧ B) → break bar: ¬A ◯ ¬B, change ∧ to ∨: ¬A ∨ ¬B
- ¬(A ∨ B) → break bar: ¬A ◯ ¬B, change ∨ to ∧: ¬A ∧ ¬B

### Truth Table for →
**"Only False when True leads to False"**
- T → F = F (only false case)
- All other cases are true

### Power Set
**"Two choices per element: in or out"**
- n elements → 2ⁿ subsets

---

## Common Mistakes to Avoid

### In Permutations & Combinations
❌ Using permutation when order doesn't matter
✓ Ask: "Does ABC differ from CBA?" If no → combination

❌ Forgetting to account for identical objects
✓ Always divide by factorials of repeated items

❌ Not considering restrictions properly
✓ Handle restrictions first (fix positions, then arrange rest)

### In Sets
❌ Confusing ⊆ with ⊂
✓ A ⊆ B allows A = B; A ⊂ B doesn't

❌ Forgetting empty set is subset of all sets
✓ ∅ ⊆ A always true

❌ Mixing up union and intersection
✓ Union = OR (more elements), Intersection = AND (fewer elements)

### In Logic
❌ Treating → like everyday "if-then"
✓ F → anything is always TRUE (vacuously true)

❌ Confusing contrapositive with converse
✓ Contrapositive: p → q ≡ ¬q → ¬p (equivalent)
✓ Converse: q → p (NOT equivalent)

❌ Negating quantifiers incorrectly
✓ "Not all" = "Some are not" = ∃x ¬P(x)

---

## Exam Preparation Checklist

### Week Before Exam
- [ ] Review all three modules thoroughly
- [ ] Create your own formula sheet
- [ ] Solve 10 problems from each topic
- [ ] Identify weak areas and focus on them
- [ ] Practice proof techniques (especially for logic and sets)

### Day Before Exam
- [ ] Review this cheat sheet
- [ ] Skim through all examples in notes
- [ ] Do 2-3 mixed problems from each module
- [ ] Rest well - don't cram!

### During Exam
- [ ] Read all questions first
- [ ] Start with easiest questions
- [ ] Show all work clearly
- [ ] Double-check calculations
- [ ] Manage time wisely (don't spend too long on one problem)

---

## Practice Problem Set (Mixed)

**Problem 1**: How many 5-letter words can be formed from "DISCRETE" if:
(a) No restrictions
(b) Must start with a vowel
(c) All letters must be distinct

**Problem 2**: In a group of 100 students:
- 60 like Mathematics
- 50 like Physics
- 40 like Chemistry
- 30 like both Math and Physics
- 20 like both Physics and Chemistry
- 15 like both Math and Chemistry
- 10 like all three
Find:
(a) How many like at least one subject?
(b) How many like exactly one subject?

**Problem 3**: Prove using set laws: A - (B ∩ C) = (A - B) ∪ (A - C)

**Problem 4**: Determine if the following argument is valid:
```
If I study hard, I will pass the exam.
I passed the exam.
Therefore, I studied hard.
```

**Problem 5**: Find the coefficient of x⁷y⁸ in the expansion of (2x + 3y)¹⁵.

**Problem 6**: How many ways can 10 identical balls be distributed among 4 children if each child must get at least 2 balls?

---

## Final Words

**Success Tips**:
1. **Practice regularly** - Do at least 5 problems daily
2. **Understand, don't memorize** - Know WHY formulas work
3. **Use multiple approaches** - Try different methods for same problem
4. **Make connections** - See how topics relate
5. **Stay organized** - Keep notes systematic
6. **Ask questions** - Clarify doubts immediately
7. **Time management** - Practice under timed conditions

**Remember**:
- Discrete Mathematics is the foundation of Computer Science
- These concepts appear in algorithms, databases, AI, and more
- Master the basics now, and advanced topics will be easier
- Consistent practice is key to excellence

**Good luck with your studies!**

---

## References and Further Reading

1. Rosen, K. H. - *Discrete Mathematics and Its Applications*
2. Johnsonbaugh, R. - *Discrete Mathematics*
3. Lipschutz, S. - *Schaum's Outline of Discrete Mathematics*
4. Course materials from RV University CS1812
5. Practice problems from various competitive exams

---

**Document Version**: 1.0  
**Last Updated**: January 2026  
**Course**: CS1812 - Discrete Mathematics & Set Theory  
**Institution**: RV University, Computer Science Department

---

END OF COMPREHENSIVE STUDY NOTES