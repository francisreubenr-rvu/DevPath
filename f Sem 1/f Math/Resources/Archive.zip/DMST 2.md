# Ultimate Comprehensive Study Notes on Discrete Mathematics
## A Complete Mastery Guide for First-Year Computer Science

### Overview

This comprehensive study guide covers the foundational topics of **Discrete Mathematics**, essential for first-year Computer Science students specializing in Artificial Intelligence and Machine Learning. The material integrates logic, set theory, relations and functions, counting principles, and mathematical proofs—all fundamental to algorithmic thinking, data structures, and computational mathematics. These notes are designed as your **primary resource** for achieving excellence in exams and competitive assessments.

**Key Focus Areas:** Sets & Functions | Relations | Propositional Logic | Counting Techniques | Permutations & Combinations | Pigeonhole Principle | Mathematical Proofs

---

## MODULE 1: SET THEORY & BASIC STRUCTURES

### Unit 1.1: Fundamentals of Sets

#### Definition and Notation
A **set** is a well-defined collection of distinct objects called **elements** or **members**. Sets are typically denoted by capital letters (A, B, C, etc.), while elements are denoted by lowercase letters.

**Membership Notation:**
- \(a \in S\): Element *a* belongs to set *S*
- \(a \notin S\): Element *a* does not belong to set *S*

#### Methods of Set Representation

**1. Roster Form (Tabular Method):** Explicitly list all elements separated by commas within braces.
- Example: \(A = \{1, 3, 5, 7, 9\}\) (odd numbers less than 10)

**2. Set Builder Form (Rule Method):** Describe the property that characterizes elements.
- Example: \(B = \{x \mid x \text{ is even}, x > 0\} = \{2, 4, 6, 8, \ldots\}\)

#### Standard Sets (Important Notation)
- \(\mathbb{N} = \{1, 2, 3, \ldots\}\): Natural/Positive Integers
- \(\mathbb{Z} = \{\ldots, -2, -1, 0, 1, 2, \ldots\}\): All Integers
- \(\mathbb{Q} = \{\frac{p}{q} \mid p, q \in \mathbb{Z}, q \neq 0\}\): Rational Numbers
- \(\mathbb{R}\): Real Numbers
- \(\mathbb{C} = \{a + bi \mid a, b \in \mathbb{R}, i = \sqrt{-1}\}\): Complex Numbers

Relationship: \(\mathbb{N} \subset \mathbb{Z} \subset \mathbb{Q} \subset \mathbb{R} \subset \mathbb{C}\)

#### Cardinality of Sets
**Definition:** The cardinality (or order) of a set \(A\), denoted \(n(A)\) or \(|A|\), is the number of elements in the set.

- Example: If \(A = \{5, 10, 15, 20\}\), then \(n(A) = 4\)
- Empty set: \(n(\emptyset) = 0\)

#### Special Sets

| Set Type | Definition | Example |
|----------|-----------|---------|
| **Empty/Null Set** | Contains no elements; denoted \(\emptyset\) or \(\varnothing\) | \(\{x \mid x \in \mathbb{N}, x < 1\} = \emptyset\) |
| **Singleton Set** | Contains exactly one element | \(\{0\}\), \(\{\text{even primes}\} = \{2\}\) |
| **Finite Set** | Contains a countable, limited number of elements | \(\{1, 2, 3\}\), days of the week |
| **Infinite Set** | Contains unlimited number of elements | \(\mathbb{N}\), \(\{2, 4, 6, \ldots\}\) |
| **Equivalent Sets** | Same cardinality but different elements | \(\{1,2,3\}\) and \(\{a,b,c\}\) have \(n = 3\) |
| **Equal Sets** | Same elements; order and repetition don't matter | \(\{1,2,3\} = \{3,1,2\} = \{1,2,2,3\}\) |
| **Subset** | All elements of A are in B; written \(A \subseteq B\) | \(\{1,2\} \subseteq \{1,2,3\}\) |
| **Proper Subset** | A is subset of B but \(A \neq B\); written \(A \subset B\) | \(\{1,2\} \subset \{1,2,3\}\) |
| **Universal Set** | Contains all elements under consideration; denoted \(U\) | In geometry context: \(U = \mathbb{R}^2\) (all points in plane) |
| **Disjoint Sets** | Have no common elements; \(A \cap B = \emptyset\) | \(\{1,2,3\}\) and \(\{4,5,6\}\) |

#### Key Properties of Subsets

**Theorem 1.1:** For any sets A, B, C:
1. \(A \subseteq A\) (Reflexive)
2. If \(A \subseteq B\) and \(B \subseteq A\), then \(A = B\) (Antisymmetric)
3. If \(A \subseteq B\) and \(B \subseteq C\), then \(A \subseteq C\) (Transitive)

**Theorem 1.2:** For any set A:
- \(\emptyset \subseteq A \subseteq U\)
- \(A \subseteq A\)

#### Power Set
**Definition:** The **power set** of A, denoted \(\mathcal{P}(A)\) or \(2^A\), is the set of all subsets of A.

**Formula:** If \(|A| = n\), then \(|\mathcal{P}(A)| = 2^n\)

**Example:** If \(A = \{1, 2, 3\}\), then
\[\mathcal{P}(A) = \{\emptyset, \{1\}, \{2\}, \{3\}, \{1,2\}, \{1,3\}, \{2,3\}, \{1,2,3\}\}\]
Number of subsets = \(2^3 = 8\)

### Unit 1.2: Set Operations

#### Fundamental Operations

**1. Union** \(A \cup B\)
- Definition: All elements in A or in B (or both)
- Formula: \(A \cup B = \{x \mid x \in A \text{ or } x \in B\}\)
- Property: Both \(A \subseteq A \cup B\) and \(B \subseteq A \cup B\)

**Example:** \(A = \{1, 2, 3\}\), \(B = \{3, 4, 5\} \Rightarrow A \cup B = \{1, 2, 3, 4, 5\}\)

**2. Intersection** \(A \cap B\)
- Definition: Elements common to both A and B
- Formula: \(A \cap B = \{x \mid x \in A \text{ and } x \in B\}\)
- Property: Both \(A \cap B \subseteq A\) and \(A \cap B \subseteq B\)

**Example:** \(A = \{1, 2, 3\}\), \(B = \{3, 4, 5\} \Rightarrow A \cap B = \{3\}\)

**3. Complement** \(A^c\) or \(\bar{A}\)
- Definition: All elements in universal set U but not in A
- Formula: \(A^c = \{x \mid x \in U, x \notin A\}\)

**Example:** If \(U = \{1,2,3,4,5\}\) and \(A = \{1, 3, 5\}\), then \(A^c = \{2, 4\}\)

**4. Difference** \(A \setminus B\) or \(A - B\)
- Definition: Elements in A but not in B
- Formula: \(A \setminus B = \{x \mid x \in A, x \notin B\}\)
- Note: \(A \setminus B = A \cap B^c\)

**Example:** \(A = \{1, 2, 3\}\), \(B = \{3, 4, 5\} \Rightarrow A \setminus B = \{1, 2\}\)

**5. Symmetric Difference** \(A \oplus B\)
- Definition: Elements in exactly one of A or B
- Formula: \(A \oplus B = (A \setminus B) \cup (B \setminus A) = (A \cup B) \setminus (A \cap B)\)

**Example:** \(A = \{1, 2, 3\}\), \(B = \{3, 4, 5\} \Rightarrow A \oplus B = \{1, 2, 4, 5\}\)

#### Algebra of Sets: Key Laws

| Law | Union Form | Intersection Form |
|-----|-----------|-------------------|
| **Idempotent** | \(A \cup A = A\) | \(A \cap A = A\) |
| **Commutative** | \(A \cup B = B \cup A\) | \(A \cap B = B \cap A\) |
| **Associative** | \((A \cup B) \cup C = A \cup (B \cup C)\) | \((A \cap B) \cap C = A \cap (B \cap C)\) |
| **Identity** | \(A \cup \emptyset = A\) | \(A \cap U = A\) |
| **Domination** | \(A \cup U = U\) | \(A \cap \emptyset = \emptyset\) |
| **Complement** | \(A \cup A^c = U\) | \(A \cap A^c = \emptyset\) |
| **De Morgan's** | \((A \cup B)^c = A^c \cap B^c\) | \((A \cap B)^c = A^c \cup B^c\) |
| **Distributive** | \(A \cup (B \cap C) = (A \cup B) \cap (A \cup C)\) | \(A \cap (B \cup C) = (A \cap B) \cup (A \cap C)\) |
| **Involution** | \((A^c)^c = A\) | - |
| **Absorption** | \(A \cup (A \cap B) = A\) | \(A \cap (A \cup B) = A\) |

#### Principle of Duality
If an equation E is an identity using set operations, then its **dual** E* (obtained by replacing \(\cup \leftrightarrow \cap\) and \(U \leftrightarrow \emptyset\)) is also an identity.

**Example:** \((A \cup B) \cap U = A \cup B\) and its dual \((A \cap B) \cup \emptyset = A \cap B\) are both identities.

### Unit 1.3: Counting Principles

#### Inclusion-Exclusion Principle

**For Two Sets:**
\[n(A \cup B) = n(A) + n(B) - n(A \cap B)\]

**For Three Sets:**
\[n(A \cup B \cup C) = n(A) + n(B) + n(C) - n(A \cap B) - n(A \cap C) - n(B \cap C) + n(A \cap B \cap C)\]

**Key Corollaries:**
- \(n(A \setminus B) = n(A) - n(A \cap B)\)
- \(n(A^c) = n(U) - n(A)\)
- If A and B are disjoint: \(n(A \cup B) = n(A) + n(B)\)

#### Problem-Solving Strategy for Inclusion-Exclusion

1. Identify all relevant sets and universal set
2. Determine cardinality of individual sets
3. Find intersections systematically
4. Apply the inclusion-exclusion formula
5. Verify answer makes logical sense

**Example:** In a class of 100 students:
- 60 like Mathematics
- 45 like Physics
- 15 like both

Find: (a) Only Math (b) Only Physics (c) At least one subject

**Solution:**
- (a) \(n(\text{Math only}) = 60 - 15 = 45\)
- (b) \(n(\text{Physics only}) = 45 - 15 = 30\)
- (c) \(n(\text{Math} \cup \text{Physics}) = 60 + 45 - 15 = 90\)

---

## MODULE 2: RELATIONS AND FUNCTIONS

### Unit 2.1: Cartesian Products and Relations

#### Cartesian Product
**Definition:** For sets A and B, the Cartesian product \(A \times B\) is the set of all ordered pairs (a, b) where \(a \in A\) and \(b \in B\).

\[A \times B = \{(a, b) \mid a \in A, b \in B\}\]

**Properties:**
1. \(A \times B \neq B \times A\) (unless A = B or one is empty)
2. \(n(A \times B) = n(A) \cdot n(B)\)
3. \((a, b) = (c, d)\) if and only if \(a = c\) and \(b = d\)
4. If either A or B is empty, then \(A \times B = \emptyset\)

**Example:** If \(A = \{1, 2\}\) and \(B = \{x, y\}\), then
\[A \times B = \{(1, x), (1, y), (2, x), (2, y)\}\]

#### Relations

**Definition:** A **relation** R from set A to set B is any subset of \(A \times B\).
- If \((a, b) \in R\), we write \(a \, R \, b\) ("a is related to b")
- If \((a, b) \notin R\), we write \(a \not R \, b\)

**Components of a Relation:**
- **Domain:** \(\{a \in A \mid \exists b \in B \text{ such that } (a, b) \in R\}\)
- **Range/Image:** \(\{b \in B \mid \exists a \in A \text{ such that } (a, b) \in R\}\)
- **Codomain:** The set B
- **Inverse Relation:** \(R^{-1} = \{(b, a) \mid (a, b) \in R\}\)

**Example:** Let \(A = \{1, 2, 3\}\) and \(B = \{2, 3, 4\}\), with relation R: "a divides b"
- \(R = \{(1, 2), (1, 3), (1, 4), (2, 2), (2, 4), (3, 3)\}\)
- Domain = \(\{1, 2, 3\}\)
- Range = \(\{2, 3, 4\}\)

### Unit 2.2: Representations of Relations

#### Matrix Representation
For relation \(R: A \rightarrow B\) with \(A = \{a_1, \ldots, a_m\}\) and \(B = \{b_1, \ldots, b_n\}\), the relation matrix \(M_R\) is an \(m \times n\) matrix where:

\[M_R[i, j] = \begin{cases} 1 & \text{if } a_i R b_j \\ 0 & \text{if } a_i \not R b_j \end{cases}\]

**Example:** For \(A = \{1, 2\}\), \(B = \{3, 4\}\), \(R = \{(1, 3), (2, 4)\}\):
\[M_R = \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}\]

#### Directed Graph (Digraph) Representation
- Vertices represent elements of A (or both if \(R \subseteq A \times A\))
- A directed edge from a to b represents \((a, b) \in R\)
- Self-loops represent reflexive pairs \((a, a)\)

**Example:** For \(A = \{1, 2, 3\}\) with \(R = \{(1, 2), (2, 3), (1, 3)\}\), draw edges: 1→2, 2→3, 1→3

### Unit 2.3: Properties of Relations

#### Reflexive Relation
**Definition:** A relation R on set A is **reflexive** if for every \(a \in A\), we have \((a, a) \in R\).

Formally: \(\forall a \in A: (a, a) \in R\)

**Matrix Characterization:** Main diagonal contains all 1s.

**Example:** "Equality" on real numbers: \(\{(x, x) \mid x \in \mathbb{R}\}\) is reflexive

#### Symmetric Relation
**Definition:** A relation R on A is **symmetric** if whenever \((a, b) \in R\), then \((b, a) \in R\).

Formally: \(\forall a, b \in A: (a, b) \in R \Rightarrow (b, a) \in R\)

**Matrix Characterization:** \(M_R = M_R^T\) (matrix equals its transpose)

**Example:** "Is sibling of" is symmetric; if a is sibling of b, then b is sibling of a

#### Transitive Relation
**Definition:** A relation R on A is **transitive** if whenever \((a, b) \in R\) and \((b, c) \in R\), then \((a, c) \in R\).

Formally: \(\forall a, b, c \in A: [(a, b) \in R \land (b, c) \in R] \Rightarrow (a, c) \in R\)

**Example:** "Less than" on integers is transitive: if \(a < b\) and \(b < c\), then \(a < c\)

#### Antisymmetric Relation
**Definition:** A relation R on A is **antisymmetric** if whenever \((a, b) \in R\) and \((b, a) \in R\), then \(a = b\).

Formally: \(\forall a, b \in A: [(a, b) \in R \land (b, a) \in R] \Rightarrow a = b\)

**Example:** "Less than or equal to" on real numbers is antisymmetric

#### Equivalence Relation
**Definition:** A relation R on set A is an **equivalence relation** if it is reflexive, symmetric, and transitive.

**Equivalence Classes:** For an element \(a \in A\), the equivalence class \([a]\) consists of all elements related to a:
\[[a] = \{x \in A \mid x \, R \, a\}\]

**Partition Property:** Equivalence relations partition the set into disjoint equivalence classes.

**Example:** "Congruence modulo 5" on integers:
- \(a \equiv b \pmod{5} \text{ iff } 5 | (a - b)\)
- Equivalence classes: \([0], [1], [2], [3], [4]\) (covering all integers)

#### Important Relation Summary Table

| Property | Definition | Key Characteristic | Example |
|----------|-----------|-------------------|---------|
| **Reflexive** | \((a,a) \in R \, \forall a\) | Diagonal all 1s in matrix | Equality, ≤ |
| **Symmetric** | \((a,b) \in R \Rightarrow (b,a) \in R\) | Matrix symmetric about diagonal | Sibling relation |
| **Transitive** | \((a,b) \in R \land (b,c) \in R \Rightarrow (a,c) \in R\) | No broken paths | Less than |
| **Antisymmetric** | \((a,b) \in R \land (b,a) \in R \Rightarrow a = b\) | No symmetric pairs except diagonals | \(\leq\), divides |
| **Equivalence** | Reflexive + Symmetric + Transitive | Creates partitions with equivalence classes | Modular equivalence |

### Unit 2.4: Functions

#### Function Definition
**Definition:** A **function** \(f: A \rightarrow B\) is a special relation where each element \(a \in A\) is paired with exactly one element \(b \in B\).

Formally: \(\forall a \in A, \exists! b \in B: (a, b) \in f\)

**Terminology:**
- **Domain:** Set A (input values)
- **Codomain:** Set B (possible output values)
- **Range/Image:** \(f(A) = \{f(a) \mid a \in A\} \subseteq B\) (actual output values)
- **Notation:** \(f(a) = b\) means "(a, b) is in function f"

**Example:** \(f(x) = 2x + 1\) from \(\mathbb{R} \to \mathbb{R}\)
- Domain: \(\mathbb{R}\)
- Codomain: \(\mathbb{R}\)
- Range: \(\mathbb{R}\) (all real numbers)

#### Function Properties

**Injective (One-to-One) Function:**
- **Definition:** Different inputs map to different outputs
- **Formal:** \(\forall a_1, a_2 \in A: f(a_1) = f(a_2) \Rightarrow a_1 = a_2\)
- **Test:** No horizontal line intersects graph more than once
- **Example:** \(f(x) = 2x\) is injective; \(f(x) = x^2\) is not

**Surjective (Onto) Function:**
- **Definition:** Every element in codomain has a preimage in domain
- **Formal:** \(\forall b \in B, \exists a \in A: f(a) = b\)
- **Test:** Range equals codomain
- **Example:** \(f: \mathbb{Z} \to \{0, 1\}\) defined by \(f(n) = n \bmod 2\) is surjective

**Bijective (One-to-One and Onto) Function:**
- **Definition:** Function is both injective and surjective
- **Importance:** Bijections establish one-to-one correspondence; inverse functions exist only for bijections
- **Example:** \(f(x) = 2x + 1\) from \(\mathbb{R} \to \mathbb{R}\) is bijective

#### Inverse Functions

**Definition:** If \(f: A \rightarrow B\) is bijective, the **inverse function** \(f^{-1}: B \rightarrow A\) is defined by:
\[f^{-1}(b) = a \text{ if and only if } f(a) = b\]

**Properties:**
- \(f^{-1}(f(a)) = a \, \forall a \in A\)
- \(f(f^{-1}(b)) = b \, \forall b \in B\)
- \((f^{-1})^{-1} = f\)

**Example:** \(f(x) = 2x + 1\) has inverse \(f^{-1}(x) = \frac{x-1}{2}\)

#### Function Composition

**Definition:** Given \(f: A \to B\) and \(g: B \to C\), the **composition** \(g \circ f: A \to C\) is defined by:
\[(g \circ f)(a) = g(f(a))\]

**Properties:**
- Composition is associative: \((h \circ g) \circ f = h \circ (g \circ f)\)
- Composition is NOT commutative: \(f \circ g \neq g \circ f\) (generally)
- If f and g are bijective, then \(g \circ f\) is bijective

**Example:** \(f(x) = x + 1\), \(g(x) = 2x\)
\[(g \circ f)(x) = g(f(x)) = g(x+1) = 2(x+1) = 2x + 2\]
\[(f \circ g)(x) = f(g(x)) = f(2x) = 2x + 1\]

Note: \(g \circ f \neq f \circ g\)

---

## MODULE 3: PROPOSITIONAL LOGIC

### Unit 3.1: Foundations of Logic

#### Propositions and Truth Values

**Definition:** A **proposition** (or statement) is a declarative sentence that is either true (T or 1) or false (F or 0), but not both.

**Examples:**
- "2 + 2 = 4" is a proposition (TRUE)
- "Bangalore is in Karnataka" is a proposition (TRUE)
- "3 is an even number" is a proposition (FALSE)
- "Is it raining?" is NOT a proposition (question)
- "This sentence is false" is NOT a proposition (paradox)

**Truth Value:** The property of being true or false. Denoted T/1 for true, F/0 for false.

**Propositional Variables:** Represented by lowercase letters (p, q, r, s, etc.)

### Unit 3.2: Logical Connectives and Operations

| Connective | Symbol | Operation | Definition |
|-----------|--------|-----------|-----------|
| **Negation** | \(\neg p\) or \(\bar{p}\) | NOT | True iff p is false |
| **Conjunction** | \(p \land q\) | AND | True iff both p and q are true |
| **Disjunction** | \(p \lor q\) | OR | True iff at least one is true |
| **Conditional** | \(p \rightarrow q\) | IF-THEN | False only when p is true and q is false |
| **Biconditional** | \(p \leftrightarrow q\) | IFF | True iff p and q have same truth value |

#### Truth Tables for Basic Operations

**Negation:**
| p | \(\neg p\) |
|---|----------|
| T | F |
| F | T |

**Conjunction (AND):**
| p | q | \(p \land q\) |
|---|---|-----------|
| T | T | T |
| T | F | F |
| F | T | F |
| F | F | F |

**Disjunction (OR):**
| p | q | \(p \lor q\) |
|---|---|-----------|
| T | T | T |
| T | F | T |
| F | T | T |
| F | F | F |

**Conditional (IF-THEN):**
| p | q | \(p \rightarrow q\) |
|---|---|---------------|
| T | T | T |
| T | F | **F** |
| F | T | T |
| F | F | T |

**Biconditional (IFF):**
| p | q | \(p \leftrightarrow q\) |
|---|---|------------------|
| T | T | T |
| T | F | F |
| F | T | F |
| F | F | T |

### Unit 3.3: Compound Propositions and Truth Tables

A **compound proposition** combines simple propositions using logical connectives.

**Example:** Construct truth table for \((p \land q) \lor (\neg p)\)

| p | q | \(p \land q\) | \(\neg p\) | \((p \land q) \lor (\neg p)\) |
|---|---|-----------|--------|--------------------------|
| T | T | T | F | T |
| T | F | F | F | F |
| F | T | F | T | T |
| F | F | F | T | T |

### Unit 3.4: Tautologies, Contradictions, and Contingencies

**Tautology:** A compound proposition that is always TRUE regardless of truth values of components.

**Example:** \(p \lor \neg p\) (Law of Excluded Middle)
| p | \(\neg p\) | \(p \lor \neg p\) |
|---|---------|---------------|
| T | F | **T** |
| F | T | **T** |

**Contradiction:** A compound proposition that is always FALSE.

**Example:** \(p \land \neg p\) (Law of Non-Contradiction)
| p | \(\neg p\) | \(p \land \neg p\) |
|---|---------|----------------|
| T | F | **F** |
| F | T | **F** |

**Contingency:** A proposition that is neither tautology nor contradiction (sometimes true, sometimes false).

**Example:** \(p \land q\) is contingent.

### Unit 3.5: Logical Equivalences

**Definition:** Two propositions P and Q are **logically equivalent** (written \(P \equiv Q\)) if they have identical truth values for all possible truth value assignments.

#### De Morgan's Laws
\[\neg(p \land q) \equiv \neg p \lor \neg q\]
\[\neg(p \lor q) \equiv \neg p \land \neg q\]

#### Conditional Equivalences
\[p \rightarrow q \equiv \neg p \lor q\]
\[p \rightarrow q \equiv \neg q \rightarrow \neg p \text{ (Contrapositive - logically equivalent)}\]
\[\neg(p \rightarrow q) \equiv p \land \neg q\]

#### Biconditional Equivalence
\[p \leftrightarrow q \equiv (p \rightarrow q) \land (q \rightarrow p)\]
\[p \leftrightarrow q \equiv (p \land q) \lor (\neg p \land \neg q)\]

#### Other Key Equivalences
- **Double Negation:** \(\neg(\neg p) \equiv p\)
- **Commutativity:** \(p \land q \equiv q \land p\); \(p \lor q \equiv q \lor p\)
- **Associativity:** \((p \land q) \land r \equiv p \land (q \land r)\); \((p \lor q) \lor r \equiv p \lor (q \lor r)\)
- **Distributivity:** \(p \land (q \lor r) \equiv (p \land q) \lor (p \land r)\); \(p \lor (q \land r) \equiv (p \lor q) \land (p \lor r)\)
- **Idempotence:** \(p \land p \equiv p\); \(p \lor p \equiv p\)
- **Absorption:** \(p \land (p \lor q) \equiv p\); \(p \lor (p \land q) \equiv p\)

### Unit 3.6: Predicates and Quantifiers

#### Predicate Logic
A **predicate** is a statement containing a variable that becomes a proposition when the variable is assigned a value.

**Notation:** \(P(x)\) represents predicate with variable x

**Example:** \(P(x): x > 5\)
- \(P(3)\) is FALSE
- \(P(7)\) is TRUE
- \(P(x)\) is neither true nor false until x is specified

#### Universal Quantifier (\(\forall\))
**Meaning:** "For all," "for every"

**Notation:** \(\forall x \in A, P(x)\) means P(x) is true for every element in A

**Truth Condition:** TRUE if P(x) is true for every x in domain; FALSE if there exists at least one x for which P(x) is false

**Example:** "\(\forall x \in \mathbb{R}, x^2 \geq 0\)" is TRUE

#### Existential Quantifier (\(\exists\))
**Meaning:** "There exists," "there is at least one"

**Notation:** \(\exists x \in A, P(x)\) means P(x) is true for at least one element in A

**Truth Condition:** TRUE if P(x) is true for at least one x; FALSE if P(x) is false for all x

**Example:** "\(\exists x \in \mathbb{R}, x^2 = 4\)" is TRUE (x = ±2)

#### Negation of Quantified Statements

\[\neg(\forall x, P(x)) \equiv \exists x, \neg P(x)\]
\[\neg(\exists x, P(x)) \equiv \forall x, \neg P(x)\]

**In words:**
- The negation of "all have property P" is "at least one doesn't have property P"
- The negation of "at least one has property P" is "none have property P"

### Unit 3.7: Conditional Statements (Advanced)

Given a conditional \(p \rightarrow q\):
- **Converse:** \(q \rightarrow p\) (NOT logically equivalent)
- **Inverse:** \(\neg p \rightarrow \neg q\) (NOT logically equivalent)
- **Contrapositive:** \(\neg q \rightarrow \neg p\) (LOGICALLY EQUIVALENT)

**Important:** A conditional and its contrapositive are logically equivalent. The converse and inverse are logically equivalent to each other but not to the original.

**Example:** "If it is raining, then the ground is wet"
- Converse: "If ground is wet, then it is raining" (different meaning, not necessarily true)
- Inverse: "If it is not raining, then ground is not wet" (false if sprinkler is on)
- Contrapositive: "If ground is not wet, then it is not raining" (true! logically equivalent)

---

## MODULE 4: COUNTING PRINCIPLES

### Unit 4.1: Fundamental Counting Principles

#### Multiplication Principle (Fundamental Counting Principle)
If an event E can occur in m ways, and for each way E occurs, another event F can occur in n ways, then both E and F can occur (in that order) in \(m \times n\) ways.

**Generalization:** For k sequential tasks with \(n_1, n_2, \ldots, n_k\) ways respectively:
\[\text{Total ways} = n_1 \times n_2 \times \cdots \times n_k\]

**Examples:**
1. **License Plates:** How many 3-digit license plates can be made with digits 0-9 if repetition is allowed?
   - First digit: 10 choices
   - Second digit: 10 choices
   - Third digit: 10 choices
   - Total: \(10 \times 10 \times 10 = 1000\)

2. **Outfits:** If you have 3 shirts, 4 pants, and 2 pairs of shoes, how many outfits can you make?
   - Total: \(3 \times 4 \times 2 = 24\) outfits

#### Addition Principle
If events E and F are mutually exclusive (cannot occur simultaneously) and E can occur in m ways while F can occur in n ways, then E or F can occur in \(m + n\) ways.

**Example:** To get from city A to city B, you can either take 3 different bus routes or 2 different train routes. How many ways to travel from A to B?
- Total: \(3 + 2 = 5\) ways

### Unit 4.2: Permutations

**Definition:** A **permutation** is an arrangement of distinct objects where order matters.

#### Permutations of n Distinct Objects
The number of ways to arrange all n distinct objects is:
\[P(n, n) = n! = n \times (n-1) \times (n-2) \times \cdots \times 2 \times 1\]

**Factorial Notation:** \(0! = 1\) by convention

**Example:** How many ways to arrange letters in BOOK (treating all as distinct)?
\[4! = 4 \times 3 \times 2 \times 1 = 24\]

#### Permutations of r Objects from n Distinct Objects
The number of r-permutations of n objects is:
\[P(n, r) = {}^nP_r = \frac{n!}{(n-r)!}\]

**Example:** How many 3-letter "words" can be formed from {A, B, C, D, E}?
\[P(5, 3) = \frac{5!}{(5-3)!} = \frac{120}{2} = 60\]

#### Permutations with Repetition
If repetition is allowed, the number of r-permutations from n objects is:
\[n^r\]

**Example:** How many 3-digit codes can be made from digits 1-9 if repetition is allowed?
\[9^3 = 729\]

#### Permutations of Objects with Repetitions
If among n objects, there are \(n_1\) identical of type 1, \(n_2\) identical of type 2, etc., then:
\[P = \frac{n!}{n_1! \times n_2! \times \cdots \times n_k!}\]

**Example:** Arrangements of letters in MISSISSIPPI:
- M: 1, I: 4, S: 4, P: 2, Total: 11
\[P = \frac{11!}{1! \times 4! \times 4! \times 2!} = \frac{39916800}{1 \times 24 \times 24 \times 2} = 34650\]

### Unit 4.3: Combinations

**Definition:** A **combination** is a selection of objects where order does NOT matter.

#### Combinations of r Objects from n Distinct Objects
The number of r-combinations of n objects is:
\[C(n, r) = \binom{n}{r} = {}^nC_r = \frac{n!}{r!(n-r)!}\]

**Properties:**
- \(C(n, r) = C(n, n-r)\) (Symmetry)
- \(C(n, 0) = C(n, n) = 1\)
- \(C(n, r) = \frac{n}{r} \times C(n-1, r-1)\) (Recursive)

**Example:** How many committees of 3 people can be formed from 10 people?
\[C(10, 3) = \frac{10!}{3! \times 7!} = \frac{10 \times 9 \times 8}{3 \times 2 \times 1} = 120\]

#### Combinations with Repetition
If repetition is allowed, the number of r-combinations from n types is:
\[C(n + r - 1, r) = \binom{n+r-1}{r}\]

**Example:** How many ways to select 5 pieces of fruit from 3 types (apples, oranges, bananas) if repetition allowed?
\[C(3 + 5 - 1, 5) = C(7, 5) = 21\]

#### Difference Between Permutations and Combinations

| Aspect | Permutations | Combinations |
|--------|--------------|--------------|
| **Order** | Matters | Doesn't matter |
| **Formula** | \(P(n,r) = \frac{n!}{(n-r)!}\) | \(C(n,r) = \frac{n!}{r!(n-r)!}\) |
| **Relationship** | \(P(n,r) = r! \times C(n,r)\) | - |
| **Example** | {A,B,C}, {B,A,C} are different | {A,B,C} is one selection |

### Unit 4.4: The Pigeonhole Principle

**Statement:** If n objects are placed into k containers and \(n > k\), then at least one container must contain more than one object.

**Generalized Form:** If n objects are placed into k containers, then at least one container contains at least \(\lceil \frac{n}{k} \rceil\) objects.

**Applications:**
1. **Among 13 people, at least 2 share the same birth month**
   - 13 people, 12 months: \(\lceil \frac{13}{12} \rceil = 2\)

2. **Among 367 people, at least 2 share the same birthday**
   - 367 people, 366 possible dates (including leap year)

3. **In any set of 6 integers, at least 2 have the same remainder when divided by 5**
   - 6 integers, 5 possible remainders (0-4)

### Unit 4.5: Binomial Theorem and Binomial Coefficients

#### Binomial Coefficient Identities
\[\binom{n}{r} = \binom{n-1}{r-1} + \binom{n-1}{r}\] (Pascal's Identity)

**Pascal's Triangle:** Each entry is sum of two entries above it:
```
        1
       1 1
      1 2 1
     1 3 3 1
    1 4 6 4 1
   1 5 10 10 5 1
```

#### Binomial Theorem
For any real numbers x, y and non-negative integer n:
\[(x + y)^n = \sum_{r=0}^{n} \binom{n}{r} x^{n-r} y^r\]

**Expansion:**
\[(x + y)^n = \binom{n}{0}x^n + \binom{n}{1}x^{n-1}y + \binom{n}{2}x^{n-2}y^2 + \cdots + \binom{n}{n}y^n\]

**Example:** Expand \((x + y)^3\)
\[(x + y)^3 = \binom{3}{0}x^3 + \binom{3}{1}x^2y + \binom{3}{2}xy^2 + \binom{3}{3}y^3 = x^3 + 3x^2y + 3xy^2 + y^3\]

**Corollaries:**
- \(\sum_{r=0}^{n} \binom{n}{r} = 2^n\) (Set x = y = 1)
- \(\sum_{r=0}^{n} (-1)^r\binom{n}{r} = 0\) (Set x = 1, y = -1)

#### Catalan Numbers

**Definition:** The nth Catalan number is:
\[C_n = \frac{1}{n+1}\binom{2n}{n} = \binom{2n}{n} - \binom{2n}{n+1}\]

**Sequence:** \(C_0 = 1, C_1 = 1, C_2 = 2, C_3 = 5, C_4 = 14, C_5 = 42, \ldots\)

**Applications:**
- Number of valid parenthesizations of n+1 factors
- Number of full binary trees with n+1 leaves
- Number of lattice paths from (0,0) to (n,n) not going above the diagonal

---

## MODULE 5: MATHEMATICAL PROOFS AND INDUCTION

### Unit 5.1: Introduction to Proofs

#### Proof Techniques

**1. Direct Proof**
- Assume the hypothesis is true
- Use logical steps to deduce the conclusion
- Most straightforward approach

**Example:** Prove: If n is even, then n² is even
- Assume n is even: \(n = 2k\) for some integer k
- Then \(n^2 = (2k)^2 = 4k^2 = 2(2k^2)\)
- So n² is even ✓

**2. Proof by Contrapositive**
- To prove \(p \rightarrow q\), prove \(\neg q \rightarrow \neg p\) instead
- Often easier when negations are simpler

**Example:** Prove: If n² is odd, then n is odd
- Contrapositive: If n is even, then n² is even
- This was proven above ✓

**3. Proof by Contradiction**
- Assume the negation of what you want to prove
- Derive a contradiction
- Conclude the original statement is true

**Example:** Prove: \(\sqrt{2}\) is irrational
- Assume \(\sqrt{2}\) is rational: \(\sqrt{2} = \frac{p}{q}\) where p, q coprime
- Then \(2q^2 = p^2\), so p² is even, thus p is even: \(p = 2k\)
- Then \(2q^2 = 4k^2\), so \(q^2 = 2k^2\), thus q is even
- But this contradicts that p, q are coprime
- Therefore \(\sqrt{2}\) is irrational ✓

### Unit 5.2: Mathematical Induction

#### Principle of Mathematical Induction

To prove a statement \(P(n)\) is true for all positive integers n:

**Base Case:** Verify P(1) is true

**Inductive Step:** Assume P(k) is true for some \(k \geq 1\) (Inductive Hypothesis)
Then prove P(k+1) is true using the inductive hypothesis

**Conclusion:** P(n) is true for all \(n \in \mathbb{N}\)

#### Template for Induction Proofs

```
Theorem: P(n) is true for all n ≥ 1
Proof:
  Base Case: [Verify P(1) is true]
  
  Inductive Step: 
    Assume P(k) is true for some k ≥ 1  [Inductive Hypothesis]
    
    We need to show P(k+1) is true:
    [Mathematical manipulations using IH to prove P(k+1)]
    
  Therefore, by mathematical induction, P(n) is true for all n ≥ 1. ✓
```

#### Classic Induction Problems

**Problem 1:** Prove \(\sum_{i=1}^{n} i = \frac{n(n+1)}{2}\)

**Proof:**
- **Base:** \(n = 1: \sum_{i=1}^{1} i = 1 = \frac{1 \times 2}{2}\) ✓
- **Inductive:** Assume \(\sum_{i=1}^{k} i = \frac{k(k+1)}{2}\)
  
  Then: \(\sum_{i=1}^{k+1} i = \sum_{i=1}^{k} i + (k+1) = \frac{k(k+1)}{2} + (k+1)\)
  \(= \frac{k(k+1) + 2(k+1)}{2} = \frac{(k+1)(k+2)}{2}\) ✓

**Problem 2:** Prove \(2^n > n\) for all \(n \geq 1\)

**Proof:**
- **Base:** \(n = 1: 2^1 = 2 > 1\) ✓
- **Inductive:** Assume \(2^k > k\)
  
  Then: \(2^{k+1} = 2 \times 2^k > 2 \times k = k + k \geq k + 1\) (since k ≥ 1) ✓

#### Strong Induction

**Principle:** To prove P(n) for all n ≥ 1:
- **Base Cases:** Verify P(1), P(2), ..., P(m) for some m
- **Inductive Step:** Assume P(j) true for all 1 ≤ j ≤ k, prove P(k+1)

Used when proof of P(k+1) requires multiple previous cases.

---

## MODULE 6: PRACTICE PROBLEMS AND SOLUTIONS

### Set Theory Problems

**Problem 1:** Given \(A = \{1, 2, 3, 4, 5\}\), \(B = \{4, 5, 6, 7\}\), \(C = \{1, 2, 6, 8\}\), find:
a) \(A \cup B\)
b) \(A \cap C\)
c) \((A \cup B) \cap C\)
d) \(A \setminus B\)

**Solution:**
- a) \(A \cup B = \{1, 2, 3, 4, 5, 6, 7\}\)
- b) \(A \cap C = \{1, 2\}\)
- c) \((A \cup B) \cap C = \{1, 2, 3, 4, 5, 6, 7\} \cap \{1, 2, 6, 8\} = \{1, 2, 6\}\)
- d) \(A \setminus B = \{1, 2, 3\}\)

**Problem 2:** Use Inclusion-Exclusion to solve: In a class of 100 students, 60 study Math, 50 study Physics, and 30 study both. How many study:
a) At least one subject
b) Only Math
c) Neither subject

**Solution:**
- a) \(n(M \cup P) = n(M) + n(P) - n(M \cap P) = 60 + 50 - 30 = 80\)
- b) \(n(\text{Only Math}) = n(M) - n(M \cap P) = 60 - 30 = 30\)
- c) \(n(\text{Neither}) = 100 - n(M \cup P) = 100 - 80 = 20\)

### Permutations and Combinations Problems

**Problem 1:** In how many ways can 5 distinct books be arranged on a shelf?

**Solution:** \(5! = 120\) ways

**Problem 2:** How many 3-letter words can be formed from the letters of MATHEMATICS?

**Solution:** 
- Total letters: M, A, T, H, E, M, A, T, I, C, S (M, A, T appear twice)
- Distinct letters: 8 (M, A, T, H, E, I, C, S)
- If all distinct: \(P(8, 3) = \frac{8!}{5!} = 336\)
- (This counts arrangements of 3 distinct letters)

**Problem 3:** A committee of 5 people is to be selected from 10 men and 8 women. In how many ways can this be done if at least 2 women must be on the committee?

**Solution:**
- Case 1 (2W, 3M): \(C(8,2) \times C(10,3) = 28 \times 120 = 3360\)
- Case 2 (3W, 2M): \(C(8,3) \times C(10,2) = 56 \times 45 = 2520\)
- Case 3 (4W, 1M): \(C(8,4) \times C(10,1) = 70 \times 10 = 700\)
- Case 4 (5W, 0M): \(C(8,5) = 56\)
- **Total:** \(3360 + 2520 + 700 + 56 = 6636\)

### Logic Problems

**Problem 1:** Construct truth table for \((p \rightarrow q) \land (q \rightarrow r)\)

| p | q | r | \(p \rightarrow q\) | \(q \rightarrow r\) | \((p \rightarrow q) \land (q \rightarrow r)\) |
|---|---|---|-----------|-----------|-------------------------------------|
| T | T | T | T | T | T |
| T | T | F | T | F | F |
| T | F | T | F | T | F |
| T | F | F | F | T | F |
| F | T | T | T | T | T |
| F | T | F | T | F | F |
| F | F | T | T | T | T |
| F | F | F | T | T | T |

**Problem 2:** Determine if the following is a tautology:
\(p \lor (q \land \neg p)\)

| p | q | \(q \land \neg p\) | \(p \lor (q \land \neg p)\) |
|---|---|-----------|-----------------------|
| T | T | F | T |
| T | F | F | T |
| F | T | T | T |
| F | F | F | F |

**Answer:** NOT a tautology (last row is F)

---

## QUICK REFERENCE CHEAT SHEET

### Set Operations Summary
- \(A \cup B = \{x \mid x \in A \lor x \in B\}\)
- \(A \cap B = \{x \mid x \in A \land x \in B\}\)
- \(A^c = \{x \in U \mid x \notin A\}\)
- \(|A \cup B| = |A| + |B| - |A \cap B|\)

### Permutations and Combinations
- \(n! = n(n-1)(n-2)\cdots 1\)
- \(P(n,r) = \frac{n!}{(n-r)!}\)
- \(C(n,r) = \frac{n!}{r!(n-r)!}\)
- \(P(n,r) = r! \cdot C(n,r)\)

### Logic Equivalences
- \(\neg(\neg p) \equiv p\)
- \(\neg(p \land q) \equiv \neg p \lor \neg q\)
- \(\neg(p \lor q) \equiv \neg p \land \neg q\)
- \(p \rightarrow q \equiv \neg p \lor q\)
- \(\neg(p \rightarrow q) \equiv p \land \neg q\)

### Important Formulas
- Binomial expansion: \((x+y)^n = \sum_{r=0}^{n}\binom{n}{r}x^{n-r}y^r\)
- Catalan numbers: \(C_n = \frac{1}{n+1}\binom{2n}{n}\)
- Combinations with repetition: \(\binom{n+r-1}{r}\)

### Top 10 Most Testable Concepts

1. **Inclusion-Exclusion Principle:** Fundamental for counting problems with overlaps
2. **Permutations vs Combinations:** Critical distinction in solving arrangement/selection problems
3. **De Morgan's Laws:** Essential for logic simplification and negation
4. **Logically Equivalent Statements:** Key for proof construction and problem solving
5. **Equivalence Relations:** Partition sets into equivalence classes; used in modular arithmetic
6. **Mathematical Induction:** Standard proof technique for infinite sets
7. **Bijective Functions:** Necessary for establishing one-to-one correspondence
8. **Pigeonhole Principle:** Simple but powerful for existence proofs
9. **Conditional and Contrapositive:** Often tested in logic sections
10. **Cartesian Products and Relations:** Foundation for functions, databases, and discrete structures

### Common Question Patterns with Answers

**Pattern 1: Counting with Restrictions**
- Identify total cases
- Subtract/exclude restricted cases
- Or count favorable cases directly
- Example: "At least one" problems often need inclusion-exclusion

**Pattern 2: Logic Equivalence Proofs**
- Construct truth tables OR apply logical laws
- Show both sides have identical truth values
- Reference standard equivalences (De Morgan's, etc.)

**Pattern 3: Relation Properties**
- Check reflexive: Does \((a,a) \in R\) for all a?
- Check symmetric: If \((a,b) \in R\), is \((b,a) \in R\)?
- Check transitive: If \((a,b), (b,c) \in R\), is \((a,c) \in R\)?

**Pattern 4: Function Analysis**
- Injective: Use \(f(x_1) = f(x_2) \Rightarrow x_1 = x_2\)
- Surjective: For each y in codomain, find x in domain with f(x) = y
- Bijective: Show both injective and surjective

**Pattern 5: Induction Problems**
- Clearly state P(n)
- Prove base case P(1)
- Use inductive hypothesis for P(k) to prove P(k+1)
- Conclude by principle of mathematical induction

---

## MINI QUIZ: 10 Mixed-Type Questions

**1. MCQ:** If \(|A| = 5\) and \(|B| = 8\), what is \(|A \times B|\)?
- A) 13  B) 40  C) 3  D) 5

**2. Short Answer:** State De Morgan's First Law

**3. MCQ:** How many ways to arrange 4 distinct objects?
- A) 4  B) 16  C) 24  D) 256

**4. True/False:** The relation "less than" on real numbers is transitive

**5. MCQ:** Which is logically equivalent to \(p \rightarrow q\)?
- A) \(q \rightarrow p\)  B) \(\neg p \lor q\)  C) \(\neg q \rightarrow \neg p\)  D) Both B and C

**6. Problem:** From 10 people, select 3 for a committee. How many ways?

**7. MCQ:** A function is bijective iff:
- A) Injective only  B) Surjective only  C) Both injective and surjective  D) Neither

**8. Proof:** Prove \(1 + 3 + 5 + \cdots + (2n-1) = n^2\) using induction

**9. MCQ:** Which statement is always true (tautology)?
- A) \(p \land q\)  B) \(p \lor \neg p\)  C) \(p \land \neg p\)  D) p

**10. Problem:** In a class of 60 students, 35 study Math, 40 study Science, and 20 study both. How many study at least one subject?

### ANSWERS TO MINI QUIZ

1. **B) 40** (Cartesian product: 5 × 8)
2. **\(\neg(p \land q) \equiv \neg p \lor \neg q\)**
3. **C) 24** (\(4! = 24\))
4. **True** (If a < b and b < c, then a < c)
5. **D) Both B and C** (\(\neg p \lor q\) is the conditional equivalence, \(\neg q \rightarrow \neg p\) is contrapositive)
6. **\(C(10,3) = 120\)**
7. **C) Both injective and surjective**
8. **Base: n=1: 1 = 1² ✓; Inductive: If \(\sum_{i=1}^{k}(2i-1) = k^2\), then \(\sum_{i=1}^{k+1}(2i-1) = k^2 + (2(k+1)-1) = k^2 + 2k + 1 = (k+1)^2\) ✓**
9. **B) \(p \lor \neg p\)** (Law of Excluded Middle)
10. **\(n(Math \cup Science) = 35 + 40 - 20 = 55\)**

---

## EXAM PREPARATION STRATEGY

### Time-Based Study Plan

**If 1 Week Available:**
- Day 1-2: Sets and Operations (Units 1.1-1.3)
- Day 3: Relations and Functions (Units 2.1-2.4)
- Day 4: Propositional Logic (Unit 3)
- Day 5-6: Counting Principles (Module 4)
- Day 7: Review + Practice Problems

**If 2 Weeks Available:**
- Week 1: Deep dive into Sets, Relations, Functions (Modules 1-2)
- Week 2: Logic and Counting, then comprehensive review
- Final 2 days: Full practice tests

**If 1 Month Available:**
- Week 1: Foundational concepts (Sets, Relations, Functions)
- Week 2: Logic and Reasoning
- Week 3: Counting Techniques
- Week 4: Integration and advanced problems + proofs

### Expected Question Distribution

- **Set Theory:** 15-20% (2-3 questions)
- **Relations & Functions:** 20-25% (3-4 questions)
- **Logic:** 15-20% (2-3 questions)
- **Counting:** 25-30% (4-5 questions)
- **Proofs/Induction:** 10-15% (1-2 questions)

### High-Probability Topics for Exams

1. Inclusion-Exclusion Principle (appear in 90% of exams)
2. Permutations & Combinations (80%)
3. Logical equivalences (75%)
4. Function properties (70%)
5. Relations properties (65%)

### Study Tips for Success

✓ **Create visual representations:** Venn diagrams for sets, truth tables for logic
✓ **Practice systematically:** Start with easy, progress to hard
✓ **Memorize key formulas:** Keep cheat sheet handy during practice
✓ **Attempt mock exams:** Full practice tests under timed conditions
✓ **Group concepts:** Link related topics (e.g., permutations → combinations → binomial)
✓ **Explain to others:** Teaching cements understanding

---

**Version 1.0 | Last Updated: January 2026**
**Target Audience: First-Year B.Tech Computer Science Students**
**Exam Compatibility: University Exams, GATE, Competitive Assessments**

This comprehensive guide is your ultimate resource. Master each unit systematically, practice extensively, and you're guaranteed excellence!

---

## REFERENCES (APA Format)

Rosen, K. H. (2019). *Discrete mathematics and its applications* (8th ed.). McGraw-Hill Education.

Lipschutz, S., & Lipson, M. L. (2007). *Schaum's outline of theory and problems of discrete mathematics* (3rd ed.). McGraw-Hill.

[Additional course materials from Christ University and RV University compilations]
